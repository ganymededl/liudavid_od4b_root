# Admin export of Cowork data (fallback input only)

Reference for administrators. End users cannot use this path: the skill itself never calls this API.

## What Microsoft documents

- Endpoint: `GET https://graph.microsoft.com/v1.0/copilot/users/{id}/interactionHistory/getAllEnterpriseInteractions` (Microsoft Learn: "aiInteractionHistory: getAllEnterpriseInteractions").
- Permission: Application `AiEnterpriseInteraction.Read.All` with admin consent. Delegated access is not supported.
- Licensing: the Learn page states a valid Microsoft 365 Copilot license with the "Microsoft Copilot with Graph-grounded chat" service plan is required.
- National clouds listed on the Learn page: Global, US Government L4, US Government L5 (DOD). Not 21Vianet.
- No delta query: handle paging (`@odata.nextLink`) and de-duplication (by interaction id) yourself.
- Use `$top=100`; when filtering on `createdDateTime`, give both a minimum and a maximum bound, e.g.
  `$filter=createdDateTime gt 2026-10-01T00:00:00Z and createdDateTime lt 2026-11-01T00:00:00Z`.
- Interactions from Copilot Studio agents are not returned.

## Not confirmed

- An `appClass` value for Cowork (`IPM.SkypeTeams.Message.Copilot.CoworkChat`) is **not listed** on the Learn API page as of 2026-11-23 (only Teams and BizChat appear in its examples). Test it in your tenant before relying on it, or export without an `appClass` filter and filter afterwards.

## Reshaping for this skill

The API returns `userPrompt` / `aiResponse` records grouped by `sessionId`, not a task list: there is no title, state or usedSkills field. Build one row per `sessionId` (e.g. first `userPrompt` as `title`, final `aiResponse` as `outcome_summary`, first `createdDateTime` as `created`) and hand that list to the user as a CSV/XLSX with at least a `title` column. The endpoint is per user, so a cohort export loops over each user ID; each user runs the skill on their own rows only.
