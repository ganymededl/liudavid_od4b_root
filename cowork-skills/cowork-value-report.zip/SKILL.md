---
name: cowork-value-report
description: |
  Reconstructs the signed-in user's personal Cowork business-value ESTIMATE by automatically reading their OneDrive Documents/Cowork/Tasks folder (task subfolders and their input/output file names), falling back to an attached or pasted task list: separates recurring automation-triggered runs from one-off tasks, classifies each one-off task into 8 categories, applies the Cowork Effort-Band minutes-per-task bands, and outputs a summary table, an itemized CSV for consolidation, a multi-tab Excel workbook and an offline HTML chart report. Validated in commercial Microsoft 365; for GCC, confirm Cowork availability and billing with the tenant admin first. Use when the user says "run my Cowork value", "reconstruct my use cases", "Cowork value report" or "estimate my Cowork hours saved". Do NOT use for billed or measured savings, other users' histories, or team-level performance evaluation.
metadata:
  category: analysis
  icon: DataTrending
---

# Cowork Value Report (personal ESTIMATE)

Turns the user's Cowork task folders (or, as a fallback, a task list the user supplies) into an estimate of the time and dollar value their own Cowork use represents.
Every number this skill produces is an **ESTIMATE** built from effort bands — never billed, metered or measured savings.

**Division of labour:** the model makes exactly one judgement per task — what the *title* indicates (Step 3) — and only for tasks that are new or whose title or rubric changed; earlier judgments are reused from the user's classification cache (Step 1b). OneDrive discovery is assembled and verified by `scripts/discover_tasks.py` (all pages followed, file evidence joined by folder id, incomplete reads refused), and everything else (dates, recurring detection, self-exclusion, file-extension signals, final category and confidence, band minutes, totals, CSV, run comparison) is done by `scripts/build_value_summary.py` from current evidence. Unchanged OneDrive contents, the same settings and the cached judgments give identical per-task scores and Low/Mid/High totals in any fresh session, however the listing was paged. When the cache cannot be loaded or saved, the run says it is **not guaranteed repeatable**. Never write your own Python for Steps 1–4.

## When to Use

- "Run my Cowork value" / "Cowork value report" / "estimate my Cowork hours saved"
- "Reconstruct my use cases" from my Cowork tasks
- Default: no attachment needed — the skill lists the user's OneDrive `Documents/Cowork/Tasks` folder itself in the same run
- Fallback: the user attaches or pastes a "My tasks" copy or an admin export and wants it classified and valued

## When NOT to Use

- Billed, invoiced, licensed or measured savings — this skill only estimates
- Another person's task history, or a team/department roll-up that ranks or compares people
- Performance evaluation of any individual (including the user) — decline and explain
- General productivity analytics on email/calendar data with no task list (answer directly instead)

## Platform constraint (state it when asked why input is needed)

A Cowork skill **cannot enumerate or export the user's full "My tasks" history**: prior-conversation search returns only a card of up to 3 matches with no titles or ids; `GetPriorConversation` works only for a pasted link; `GetScheduledPrompts` returns only the current task's schedule; and the Graph Copilot interaction export is application-permission only (admin-run — see [references/admin-export.md](references/admin-export.md)).
Therefore the **default INPUT is the user's OneDrive `Documents/Cowork/Tasks` folder** (each Cowork task syncs a folder there). A user-supplied task list or admin export is the **fallback**. Never rebuild the history from prior-conversation search, and never invent tasks. The folder reflects only task folders that still exist (deleted or renamed folders are not counted) — the coverage line says so.

## Workflow

### Step 1 — Task discovery → `working/tasks.json`
All inside one run, with no attachment or paste from the user. The itemized CSV (Step 5) is only the final output and is **never re-ingested** — never ask the user to export and re-upload it.

1. **User and time zone.** `GetMyDetails` for the display name; slug it with code: `python scripts/build_value_summary.py slug --name "<display name>"` (never slug by hand). `GetUserDateAndTimeZoneSettings` (load via `tool_search_tool`) for today's local date and IANA zone; if it fails, use the session date, omit `--tz` (UTC is used) and say so in one line.
   **Fix this run's file stem now:** `python scripts/build_value_summary.py run-id --name "<display name>" [--tz <IANA zone>]` → `file_stem` = `cowork_value_<slug>_<yyyy-mm-dd>-<HHMMSS>` (local date and time). The CSV, HTML and XLSX of this run all use this one stem; use its `run_date` as `--today` below.
2. **Find the Tasks folder.** `ExecuteSql` `SELECT name, id, folder FROM drive_children WHERE folder_path = '/Documents/Cowork'` and take the row named `Tasks`: keep its **id** and **`folder.childCount`**. Not found, or an access error → go to the fallback (5). Found with childCount 0 → a **confirmed empty** Tasks folder: run Step 1 (3–4) anyway (it records the confirmed-empty result) and report zero tasks.
3. **List everything, saving every page — one fixed path, no shortcuts.** Use `ExecuteSql` on `drive_children` for every listing (use `GetDriveChildren` for all of them only if `ExecuteSql` is unavailable, and say so). Every listing selects at least `id, name, parentReference, folder, createdDateTime` (`folder` carries `childCount`; `parentReference` carries the parent folder id). Save **each page the tool returns** to `working/discovery/` as its own JSON file, unedited:
   `{"listing": "root" | "subfolders" | "files", "parents": [<the folder ids this listing asked for>], "page": <0, 1, 2…>, "next": <the continuation the tool returned, or null>, "rows": [<rows exactly as returned>]}`
   - **root** — the children of the Tasks folder (`WHERE folder_path = '/Documents/Cowork/Tasks'`; `parents` may be omitted).
   - **subfolders** — the children of every task folder, ≤50 parent ids per statement (`WHERE item_id IN (...)`); include every task folder whose `childCount` > 0.
   - **files** — the children of every `input/` and `output/` folder found, ≤50 ids per statement; include every one whose `childCount` > 0.
   - **Follow every page:** request the next page while the tool returns a continuation, and save it with the next page number. Never stop early, never merge, filter, reorder or retype rows. If a call fails, retry it once; if it still fails, stop (step 4 will report the read as incomplete).
4. **Assemble and verify with code:**
   ```bash
   python scripts/discover_tasks.py --pages working/discovery --root-id <Tasks id> --root-child-count <Tasks childCount> \
     --out working/tasks.json --report working/discovery_report.json
   ```
   It follows each page chain, de-duplicates by item id, joins task folder → `input/`/`output/` → files **strictly by parent folder id**, checks every folder against its own `childCount`, and writes `tasks.json` in a fixed order with a content **fingerprint**. An empty folder is **confirmed empty** only when its `childCount` is 0; a folder with fewer listed items than `childCount`, a missing page, or a last page that still has a continuation is an **incomplete read**.
   - **Exit 3 (incomplete read):** do **not** score anything. Re-run the listings it names (step 3) once; if it still fails, report the message and stop — never fall back to a partial listing or to the supplied-list path.
   - **Exit 2 (malformed pages):** fix the saved page files from the tool output (never invent rows) and rerun.
   - **childCount not exposed by the listing tool:** exit 3 tells you so. Rerun with `--accept-pagination-only` only if the column truly cannot be selected; the report then says counts were not verified, and so must the Coverage line.
5. **Fallback — only** if the Tasks folder is not found or cannot be accessed (never for an incomplete read, and never for a confirmed-empty folder): look in `input/` and the conversation for an attached or pasted task list (CSV, XLSX, pasted table; read with `pandas`/`openpyxl`). Required column: **title**; map **state**, **created date**, **last outcome/summary** by meaning. Write the same `tasks.json` with `"title"` instead of `"name"`, plus `"state"` and `"outcome_summary"`, and empty file lists. If nothing is attached either, ask **once** for the list (one sentence on the platform constraint) and stop. Never invent, guess or pad tasks.

### Step 1b — Load the classification cache (before Step 2)
The cache holds the model's earlier **title judgments** (not final scores) and the previous run's per-task results, in the user's own OneDrive at `Documents/Cowork/ValueReports/history/cowork_value_classifications_<slug>.json` — next to the run history, outside both `Documents/Cowork/Tasks` and the skill package. Each judgment is keyed by **OneDrive folder id + a fingerprint of the exact title the model saw + the rubric version** (`RUBRIC_VERSION` in `scripts/value_constants.py`).
1. `GetDefaultDrive`, then `ExecuteSql` `SELECT name, id, size, lastModifiedDateTime FROM drive_children WHERE folder_path = '/Documents/Cowork/ValueReports/history'` (fallback `GetDriveChildren`). Keep this listing for Step 4b.
2. **Cache file exists:** `ReadFileContent(drive_id, item_id, mode="download")` → pass the `cloud/...` path to `prepare` as `--cache-in`.
   **No file or no folder:** first run — pass neither cache flag.
   **Lookup or download fails:** pass `--cache-skip "<one-line reason>"`. Every title is then judged fresh, nothing is saved, and the run is reported as not guaranteed repeatable.
3. A supplied task list (fallback input) has no stable folder ids, so the cache is not used for it; the run says so.

### Step 2 — Recurring automation (code)
1. Call `GetEventTriggers` and `GetScheduledPrompts`; write the results to `working/triggers.json` as `[{"name", "state", "fire_count", "last_fired_at"}]` (`[]` if a call fails — say so and continue).
2. Run:
   ```bash
   python scripts/build_value_summary.py prepare --tasks working/tasks.json --discovery working/discovery_report.json \
     --triggers working/triggers.json \
     --source "<OneDrive Documents/Cowork/Tasks folder | user-supplied list>" --today <yyyy-mm-dd> [--tz <IANA zone>] \
     [--cache-in <cloud path> | --cache-skip "<reason>"] --out working/value_tasks_prepared.json
   ```
   Pass `--exclude-ids <id>` **only when this run's own task-folder id is known for certain** (a tool or the session returned it). Never infer it from "newest folder" — another task may have started concurrently, or this folder may not have synced yet, and guessing can silently remove real work. When the id is unknown, omit the flag: the rules below still remove a report run that has no other output, and the Coverage line discloses that self-exclusion could not be confirmed by id.
   It first **removes the reporting skills' own runs**, strongest evidence first: the current task's folder; folders whose `output/` holds only `cowork_value_*` / `cowork_net_value_*` artifacts; and folders whose title starts with a report trigger phrase ("run my Cowork value", "net my Cowork value"…) **and** that produced no other output. A title alone never removes a task that produced other work (e.g. "Cowork value report for CUIMC — draft a deck" with a .pptx is counted), and report artifacts inside a mixed folder are ignored as evidence. Removed runs are listed in `self_runs` with a reason and never counted, so rerunning the report never adds savings by itself.
   Add `--include-unconfirmed` **only when the user asks** to count repeated/untitled tasks (e.g. "include my unconfirmed tasks"); those rows are then classified and scored like any one-off task.
   It then humanizes titles, converts `created` to the user's **local date**, sets state/outcome, reads file-extension signals and flags **recurring** rows (title matching is Unicode-aware, so titles in any script are handled):
   - **Confirmed automation** — title matches a trigger/schedule name from `GetEventTriggers`/`GetScheduledPrompts`.
   - **Unconfirmed automation** — normalized title repeated **5+** times, or a generic/date-only folder name (`untitled`, `untitled-<date>`, bare date/timestamp, `task-<n>`, `new-task-<date>`), with no matching trigger. These may be real manual work, so they are **not scored** but are reported separately (`recurring_unconfirmed`, `recurring_groups[].confirmed = false`) so the user can rename genuine tasks and rerun.
3. Recurring runs are reported **only as count + one-line characterization** — never classified or scored.

### Step 3 — Classify titles (the model's only judgement)
Read `to_classify` in `working/value_tasks_prepared.json` — it lists **only** tasks that need a judgment this run, each with a `reason` (`new task`, `title changed`, `rubric version changed`, or `cache unavailable`). Tasks with a valid cached judgment are **not** listed; never re-judge them. If `to_classify` is empty, write `{}`. For each listed id, judge the **title alone** and write `working/classifications.json`:
`{"<id>": {"title_category": "<category>" | null, "title_explicit": true|false, "rationale": "<one line>"}}`

| Category | Typical title signals |
|---|---|
| Analysis & Research | compare, analyze, research, summarize sources, data questions |
| Document & content creation | draft doc, deck, report, page, brief |
| Write or debug code | script, code, formula, query, fix a bug |
| Specialized workflows | multi-step domain processes, skills, packets, checklists |
| Email workflows | send, reply, triage, draft an email |
| Meeting workflows | schedule, prep, recap, transcript summary |
| Communication workflows | Teams message, post, short announcement |
| General assistance/Other | quick lookups, Q&A, anything else |

- `title_category` = null when the title is vague (e.g. "misc", "help").
- `title_explicit` = true only when the title has a clear action verb.
- Do not decide confidence or look at file extensions — the script does that. Every `to_classify` id must have an entry; category names must match the table exactly. Entries for ids not in `to_classify` are ignored.

The script then decides deterministically: title and file extensions (`output/` outranks `input/`) agree → **High**; they conflict → explicit title wins, else files win → **Medium**; one signal only → **Medium** (explicit title or `output/` files) or **Low**. Failed/cancelled tasks with no outcome, and folders with no `output/` files and no meaningful title, go to **Excluded** and are not scored. Extension map: code `.ps1 .psm1 .py .js .ts .sh .sql .kql`; documents `.pptx .docx .pdf .md .html`; analysis `.xlsx .csv .pbit .pbix .json`; meetings `.vtt`; email `.msg .eml`.

### Step 4 — Build the summary and CSV (code)
```bash
python scripts/build_value_summary.py build --classifications working/classifications.json --user "<display name>" \
  --summary-out working/cowork_value_summary.json --csv-out working/<file_stem>.csv \
  --cache-out working/cowork_value_classifications_<slug>.json
```
Exit 2 = bad/missing classification (message names the ids): fix `classifications.json` and re-run — never edit the summary or CSV by hand.
`build` merges cached and new title judgments, recomputes every final category, exclusion and total from current evidence, writes the updated cache (only when it was loaded or this is the first run), and adds `run_comparison` — keyed by folder id against the previous run in the cache: tasks **added**, **removed** and **changed**, each with a reason (new task folder; folder no longer listed; title changed; title judgment changed; file evidence changed; automation evidence changed), plus the Low/Mid/High delta.
Bands (source: **Cowork Value Methodology v4** — `Cowork Value Methodology v4.pptx`), minutes per task — defined once in `scripts/value_constants.py`:

| Category | Low | Mid | High |
|---|---|---|---|
| Analysis & Research | 30 | 67 | 92 |
| Document & content creation | 12 | 24 | 42 |
| Email workflows | 3 | 7 | 12 |
| Meeting workflows | 12 | 31 | 45 |
| Communication workflows | 2 | 4 | 6 |
| Specialized workflows | 10 | 25 | 40 |
| Write or debug code | 30 | 56 | 96 |
| General assistance/Other | 2 | 5 | 8 |

Hours = minutes / 60; dollars = hours × **$72/hr**. Lead with **Mid**, defend with **Low**, show **High** for completeness. The summary JSON (with `items`, `excluded`, `recurring_groups`, `classification_log`) is the single computation: the chat, CSV, HTML and XLSX all quote it; never recompute or round differently. Text cells beginning with `= + - @` are stored with a leading `'` so Excel never evaluates them.

### Step 4b — Enrich the summary (highlights, monthly trend, confidence mix, narrative, run history)
Run [scripts/enrich_value_summary.py](scripts/enrich_value_summary.py) on `working/cowork_value_summary.json` **before** any HTML or XLSX is rendered. It adds, from `items` only (standard library, deterministic): `categories[i].highlights` (up to 3 real scored tasks per category — never edit, paraphrase or invent), `monthly_trend` + `monthly_trend_status` (months of the local created date), `confidence_mix` with its ready-made `line`, `narrative_paragraph` (quote verbatim), `effort_bands`, `rate_per_hour`, `bands_source`, and `history` + `history_status`.

**Cross-run history and classification cache** — OneDrive files `Documents/Cowork/ValueReports/history/cowork_value_history_<slug>.json` and `cowork_value_classifications_<slug>.json` (the cache, from Step 1b). Upload, verify and record **both** with the steps below; use the Step 1b listing instead of a second lookup. History file: This location is deliberately **outside** both `Documents/Cowork/Tasks` (read-only) and the skill's own folder (so personal run data can never be packaged with the skill). One entry per run date; a rerun on the same date overwrites that date's entry.
1. `GetDefaultDrive`, then `ExecuteSql` `SELECT name, id, size FROM drive_children WHERE folder_path = '/Documents/Cowork/ValueReports/history'` (fallback `GetDriveChildren`).
2. **File exists:** `ReadFileContent(drive_id, item_id, mode="download")` → `cloud/...` copy; run `python scripts/enrich_value_summary.py --summary working/cowork_value_summary.json --history-in <cloud path>`.
   **No file / no folder (first run):** create the missing folders with `CreateFolder` — `ValueReports` under `Documents/Cowork`, then `history` under it — and run `... --history-new --history-out working/cowork_value_history_<slug>.json`.
   **Lookup or download fails:** run `... --history-skip "<one-line reason>"` and go on.
3. **Upload — wait first.** Run `sleep 20` after the script returns (an immediate upload can send stale bytes while reporting success), then: existing file → `UploadFileContent(workspace_path=<cloud path>)`; new file → `UploadFileContent(source_workspace_path="working/cowork_value_history_<slug>.json", file_name="cowork_value_history_<slug>.json", drive_id=..., parent_path="Documents/Cowork/ValueReports/history")` (`conflict_behavior` is `fail` only; if the name exists, use the download + in-place path).
4. **Verify:** re-list (or re-download) and compare online size/QuickXorHash or bytes with the local file. Mismatch → wait ~20 s, upload once more, verify again.
5. Record the outcome **before rendering**: `python scripts/enrich_value_summary.py --summary working/cowork_value_summary.json --set-history-status "<read and updated | created | not saved: reason>"`. Any failure is one line in the response — never a reason to stop.
6. **Cache file:** if `build` wrote `working/cowork_value_classifications_<slug>.json` (`cache_status.saved` = `pending upload`), upload it the same way — in place over the downloaded `cloud/...` copy when it existed (copy the local file over that path first), otherwise as a new file in `history/` — with the same `sleep 20` and verification. Then record it: `python scripts/build_value_summary.py cache-status --summary working/cowork_value_summary.json --saved "<saved | not saved: reason>"`. This updates the `repeatability` line; never claim the run is repeatable unless it says so.

### Step 5 — Outputs
File names: every output of this run uses the **`file_stem` from Step 1** — `<file_stem>.csv`, `<file_stem>.html`, `<file_stem>.xlsx` — fixed up front, never chosen after a publish fails. Every report run publishes into its own task folder, so a bare date name could repeat across folders; the `-<HHMMSS>` suffix keeps each run's files unique and lets cowork-net-value tell runs apart. `build` refuses a CSV path that doesn't use the stem.
1. **Summary table — "Cowork Value ESTIMATE"** from `categories`: category, tasks, Low/Mid/High hours, Mid $ and Low $, plus a totals row.
2. **Recurring automation table — "Recurring automation (not scored) — ESTIMATE scope"** from `recurring_groups`: name, runs, Confirmed? (yes = matches a trigger/schedule; no = repeated or untitled, unconfirmed), basis + your one-line characterization, trigger fire_count/last_fired_at where present.
3. **Excluded table** from `excluded`.
4. **Itemized CSV** — already written by Step 4 (UTF-8 BOM; columns `user, task_title, created_date, state, outcome_summary, recurring_flag, category, classification_confidence, low_minutes, mid_minutes, high_minutes`). Publish: `CopyArtifact(surface="output", source="working/<file_stem>.csv", destination="<file_stem>.csv")`; fall back to a direct `output/` write only if that works. Confirm the result path before saying it is saved.
5. **HTML chart report:** `python scripts/render_value_html.py --summary working/cowork_value_summary.json --out working/<file_stem>.html` — one self-contained page (inline CSS, no CDN/library/fonts/images/scripts/network), generic Microsoft-blue palette, every number labelled ESTIMATE, all text HTML-escaped. It stops if category totals don't match the headline — re-run Step 4, never edit the check. Publish with `CopyArtifact` like the CSV and confirm the path.
6. **Excel workbook:** `python scripts/build_value_xlsx.py --summary working/cowork_value_summary.json --out working/<file_stem>.xlsx --csv working/<file_stem>.csv` — tabs Summary, By Category (with month × category pivot), Raw Items (checked cell for cell against the CSV), Assumptions & Sources. No macros or formulas. Exit 3 = openpyxl unavailable: skip only this file and say so; exit 1 = data mismatch: re-run Step 4, never edit the check. Publish with `CopyArtifact` and confirm (it may come back as a live workbook handle).

## Output Format

```
**Verdict:** ESTIMATE of ~{Mid hours} assisted hours (~${Mid $}) across {N} one-off tasks; defensible floor {Low hours} h (${Low $}). Files: `<file_stem>.csv`, `<file_stem>.html` and `<file_stem>.xlsx` in output/.

Coverage: {rows} tasks from {source}, {date range}; OneDrive read {discovery.completeness} ({discovery.pages_read} pages, fingerprint {discovery.fingerprint}). History not in the input (incl. deleted/renamed task folders) is not counted.{ If recurring_unconfirmed > 0: " {recurring_unconfirmed} task(s) look like automation (repeated or untitled titles) but match no trigger, so they were not scored — rename any that were real work and rerun, or say 'include my unconfirmed tasks' to count them."}{ If included_unconfirmed > 0: " {included_unconfirmed} repeated/untitled task(s) were counted at your request."}{ If self_runs_excluded > 0: " {self_runs_excluded} Cowork value reporting run(s) were left out."}{ If self_exclusion_confirmed is false: " This run's own task folder could not be identified by id, so report runs were excluded by their files and titles only."}{ If invalid_dates_blanked > 0: " {invalid_dates_blanked} task date(s) were invalid or in the future and were left blank."}
{confidence_mix.line} (classification confidence, ESTIMATE)
Run history: {history_status}; {len(history)} run(s) recorded{; monthly chart note when monthly_trend_status is not ok}
{repeatability}

### Changes since last run ({run_comparison.previous_run_date}, or "baseline run — nothing to compare" when there is none)
Added {counts.added} · Removed {counts.removed} · Changed {counts.changed} · Unchanged {counts.unchanged}; Mid change {delta.mid_minutes} min (~${delta.mid_dollars}) ESTIMATE.
| Change | Task | Before → After | Why |   (every added, removed and changed task; omit the table when all are unchanged)

### Copy-paste summary
{narrative_paragraph — verbatim from the summary JSON}

### Cowork Value ESTIMATE — by category
| Category | Tasks | Low h | Mid h | High h | Mid $ | Low $ |
...
### Recurring automation (not scored) — ESTIMATE scope
| Name/title | Runs | Confirmed? | Basis / characterization |
### Excluded (failed/cancelled, no outcome)
### Representative examples
- **{Category}:** {task_title} — {outcome snippet}; {task_title}; … (up to 3, from `highlights`)
CSV: output/<file_stem>.csv
HTML chart report: output/<file_stem>.html
Excel workbook: output/<file_stem>.xlsx
Bands: Cowork Value Methodology v4; $72/hr loaded rate.
```
Plain business language; a few lines of prose around the tables. Name every output file by its exact filename; if a publish failed, say which one instead of listing it. If the workbook was skipped, keep the two-file wording and add: "Excel workbook skipped: openpyxl is not available in this environment."

## Final self-check (before the Verdict)

- [ ] `discover_tasks.py` exited 0 (complete read) before anything was scored; every listing page saved and followed
- [ ] `build_value_summary.py prepare` and `build` both exited 0; no Step 1–4 arithmetic or classification logic was written outside the script
- [ ] Reporting runs (`self_runs`) excluded; `--exclude-ids` used only with a known id, otherwise the unconfirmed self-exclusion is disclosed; unconfirmed automation and blanked dates reported on the Coverage line
- [ ] Chat Verdict/Coverage, CSV, HTML and XLSX all quote `working/cowork_value_summary.json`
- [ ] CSV, HTML and XLSX published (CopyArtifact result paths confirmed) or the XLSX explicitly reported as skipped
- [ ] `enrich_value_summary.py` ran before the HTML/XLSX; narrative, confidence line and highlights quoted, not retyped
- [ ] Run history read and written under `Documents/Cowork/ValueReports/history/` (upload verified after the 20 s wait) **or** reported as skipped in one line
- [ ] Classification cache loaded before Step 2 (or the reason it couldn't be); only `to_classify` ids judged; cache upload verified and recorded with `cache-status`; the `repeatability` line quoted as is
- [ ] "Changes since last run" section shown from `run_comparison`
- [ ] Unknown dates stated; monthly chart skipped rather than errored

## Guardrails

- **ESTIMATE labelling:** every headline, table title and chart number says ESTIMATE; never call figures billed, measured, actual or realized savings.
- **Coverage gap every run:** state tasks counted, the date range, and that history not in the input is not counted.
- **Provenance:** when asked "where did this number come from", cite Cowork Value Methodology v4 (`Cowork Value Methodology v4.pptx`), the category band (Low/Mid/High minutes) and the $72/hr rate.
- **Own activity only:** no performance evaluation, scoring or comparison of individuals; refuse other users' histories.
- **No fabrication:** never invent tasks, outcomes, dates or counts; vague titles get `title_category: null`, not guesses.
- **Code for logic and math:** classification decisions beyond the title judgement, all counts, hours and dollars come from the scripts.
- **Read-only:** never edit, delete or create triggers or scheduled tasks; never write to, move or delete anything in `Documents/Cowork/Tasks`; never ask the user to re-upload the generated CSV.
- **Only OneDrive write is the history file** under `Documents/Cowork/ValueReports/history/`; never write into the skill's own folder.
- **Copy-paste summary is not an appraisal:** it states estimated assisted time, not productivity, quality or performance; never add rankings, ratings or comparisons.
- **Cloud scope:** validated in commercial Microsoft 365. In GCC, Cowork availability is rolling out tenant by tenant: if the user says their tenant is GCC, note the skill has not yet been validated there and proceed only once they confirm Cowork and custom skills are enabled for them.

## Common Issues

| Issue | Fix |
|---|---|
| Tasks folder not found or empty | Fall back to an attached/pasted list; if none, ask once and stop |
| Folder has no `input/` or `output/` subfolder | Recorded as `absent` (confirmed by the task folder's childCount); empty file list in `tasks.json` |
| Listing paged/truncated | Save and follow every page; `discover_tasks.py` exits 3 if a page or continuation is missing — never score a partial listing |
| `discover_tasks.py` says a folder's listed count is below its `childCount` | Incomplete read: re-list that folder (all pages) once; still short → report and stop |
| Folder has `childCount` 0 | Confirmed empty — no listing needed; recorded as such in the discovery report |
| Two runs on unchanged OneDrive give different numbers | Compare `discovery.fingerprint` first (different = the read differed), then `run_comparison.changed[].why` |
| `build` exits 2 "classifications missing / invalid" | Add or correct those ids in `classifications.json` (exact category names or null) and re-run `build` |
| No created dates | Date range "unknown"; monthly chart replaced by a note; narrative omits the date sentence |
| Invalid or future dates in a supplied list (e.g. `2026-11-99`) | `prepare` blanks them and counts them (`invalid_dates`); the CSV never carries an impossible date; disclose on the Coverage line |
| This run's folder id is unknown | Omit `--exclude-ids`; never guess from the newest folder; disclose on the Coverage line |
| GetEventTriggers unavailable | `triggers.json` = `[]`; say so; the repeat and generic-name rules still apply |
| Many untitled/date-only folders, or 5+ similar manual titles | Reported as **unconfirmed** automation, not scored; the Coverage line states how many so the user can rename real tasks and rerun |
| A previous "run my Cowork value" / "net my Cowork value" task appears in the Tasks folder | Removed automatically as a reporting run (`self_runs`, with reason); never classified or scored |
| A real task whose title starts like a report phrase (e.g. "Cowork value report for CUIMC — draft a deck") | Kept and scored when it produced any non-report output |
| User wants repeated/untitled tasks counted | Rerun from Step 2 with `--include-unconfirmed`; the Coverage line says how many were included |
| Publish returns `source not visible yet` | Wait a few seconds and re-issue the same call once |
| Publish refused because the name already exists (two runs in the same second) | Run `run-id` again, copy the three working files to the new stem (contents unchanged), publish all three, and name them in the Verdict — never overwrite |
| `build_value_xlsx.py` exits 3 | Skip only the workbook; say "Excel workbook skipped: openpyxl is not available in this environment." |
| HTML/XLSX script stops on a totals or Raw Items mismatch | Re-run Step 4 `build`, then 4b and Step 5 — never edit the JSON, CSV or check by hand |
| History file unreadable, folder not creatable, or upload fails twice | `--history-skip "<reason>"` / `--set-history-status "not saved: <reason>"`; one line; run continues |
| History from an earlier version of this skill under `Documents/Cowork/skills/cowork-value-report/history/` | Only when the new path has no file: download the old file and run `--history-in <old cloud path> --history-out working/cowork_value_history_<slug>.json`, then upload it as a new file to `ValueReports/history/`; leave the old file in place |
| Fewer than 2 history entries | No run-history chart; a one-line note instead |
| Cache missing on a later run (deleted, moved) | Treated as a first run: every title judged fresh; the comparison has no previous run; the cache is rebuilt |
| Cache unreadable or download fails | `--cache-skip "<reason>"`; nothing reused or saved; the run says it is not guaranteed repeatable — never overwrite the unreadable file |
| Two report runs at the same time | The later cache upload wins; any judgment lost is simply re-judged on the next run and shown as `title judgment changed` only if the answer differs |
| The title-judgment rubric (Step 3 table or rules) is edited | Bump `RUBRIC_VERSION` in `scripts/value_constants.py`; every task is then re-judged once (`rubric version changed`) |
| A task's score changed with no new files or title | See `run_comparison.changed[].why`; it names the evidence that moved (e.g. automation evidence when a matching trigger was added) |
