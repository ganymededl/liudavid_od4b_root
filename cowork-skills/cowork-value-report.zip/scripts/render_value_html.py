#!/usr/bin/env python3
"""Render the Cowork Value ESTIMATE as a self-contained HTML chart report.

Standard library only. No external CSS, fonts, images, scripts or network calls.
Input: the summary JSON written once by the Step 4 computation (the same numbers
used for the chat Verdict/Coverage lines and the CSV). Output: one HTML file.

Usage:
  python render_value_html.py --summary working/cowork_value_summary.json \
      --out working/cowork_value_<user>_<yyyy-mm-dd>.html

Summary JSON shape:
{
  "user": "Display Name",
  "run_date": "yyyy-mm-dd",
  "mid_hours": 12.3, "mid_dollars": 886.0,
  "low_hours": 6.1,  "low_dollars": 439.0,
  "one_off_tasks": 20,
  "coverage": {"rows": 30, "source": "OneDrive Documents/Cowork/Tasks folder",
               "date_range": "2026-09-01 to 2026-11-20"},
  "categories": [{"category": "Analysis & Research", "tasks": 5,
                  "low_hours": 2.5, "mid_hours": 5.6, "high_hours": 7.7}, ...],
  "recurring_excluded": 8,
  "no_outcome_excluded": 2
}

Optional fields added by enrich_value_summary.py (each block is skipped when
its field is absent, so an older summary renders exactly as before):
  narrative_paragraph            -> text block under the title block
  confidence_mix.line            -> badge line in the title block
  categories[i].highlights       -> "Representative examples" callout under
                                    that category's bar in the hours chart
  monthly_trend (+ _status)      -> "Assisted hours by month" chart, or a note
  history (+ history_status)     -> "Mid assisted hours by run date" chart (2+)
"""
import argparse
import html
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from value_constants import BANDS_SOURCE, CATEGORIES, RATE_PER_HOUR  # noqa: E402

CSS = """
body{margin:0;padding:24px;font-family:'Segoe UI',system-ui,-apple-system,Arial,sans-serif;
 color:#323130;background:#F3F2F1}
.wrap{max-width:1100px;margin:0 auto}
.hero{background:#0078D4;color:#fff;border-radius:8px;padding:20px 24px;margin-bottom:20px}
.hero h1{margin:0 0 4px;font-size:22px}
.hero .sub{color:#DEECF9;font-size:14px;margin-bottom:12px}
.kpis{display:flex;flex-wrap:wrap;gap:12px}
.kpi{background:#106EBE;border-radius:6px;padding:10px 14px;min-width:200px}
.kpi .lab{font-size:12px;color:#DEECF9;text-transform:uppercase;letter-spacing:.04em}
.kpi .val{font-size:20px;font-weight:600}
.cov{margin-top:12px;font-size:13px;color:#DEECF9}
.charts{display:flex;flex-wrap:wrap;gap:20px}
.card{flex:1 1 420px;background:#fff;border:1px solid #E1DFDD;border-radius:8px;padding:16px 18px}
.card h2{margin:0 0 12px;font-size:16px;color:#005A9E}
.row{display:flex;align-items:center;margin:6px 0;font-size:13px}
.row .name{flex:0 0 180px;padding-right:8px;color:#323130}
.row .track{flex:1;background:#F3F2F1;border-radius:3px;height:20px;position:relative}
.row .bar{background:#0078D4;height:20px;border-radius:3px;min-width:2px}
.row .num{flex:0 0 120px;padding-left:8px;color:#605E5C;white-space:nowrap}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{text-align:left;padding:8px 10px;border-bottom:1px solid #E1DFDD}
th{background:#DEECF9;color:#005A9E}
.foot{margin-top:16px;font-size:12px;color:#605E5C}
.tag{font-weight:600;color:#005A9E}
"""

# Appended only when the summary carries the new optional fields.
EXTRA_CSS = """
.badge{display:inline-block;margin-top:10px;background:#005A9E;color:#fff;border-radius:12px;
 padding:3px 12px;font-size:12px}
.narr{background:#fff;border:1px solid #E1DFDD;border-left:4px solid #0078D4;border-radius:8px;
 padding:14px 18px;margin-bottom:20px;font-size:14px;line-height:1.5}
.narr h2{margin:0 0 6px;font-size:15px;color:#005A9E}
.hl{margin:-2px 0 8px 180px;padding:6px 10px;background:#DEECF9;border-radius:4px;font-size:12px;color:#323130}
.hl ul{margin:2px 0 0;padding-left:18px}
.hl .o{color:#605E5C}
.note{font-size:13px;color:#605E5C}
"""


def esc(s):
    return html.escape(str(s), quote=True)


def fmt_h(x):
    return f"{float(x):,.1f}"


def fmt_d(x):
    return f"${float(x):,.0f}"


def highlight_callout(items):
    if not items:
        return ""
    lis = []
    for h in items:
        o = str(h.get("outcome_summary", "")).strip()
        lis.append(f'<li>{esc(h["task_title"])}' + (f' <span class="o">&mdash; {esc(o)}</span>' if o else "") + "</li>")
    return ('<div class="hl">Representative examples:<ul>' + "".join(lis) + "</ul></div>")


def bar_chart(title, rows, key, fmt, unit, highlights=None):
    rows = sorted(rows, key=lambda r: (-float(r[key]), r["category"]))
    mx = max([float(r[key]) for r in rows] or [0])
    out = [f'<div class="card"><h2>{esc(title)} (ESTIMATE)</h2>']
    for r in rows:
        v = float(r[key])
        pct = (v / mx * 100.0) if mx > 0 else 0.0
        out.append(
            '<div class="row">'
            f'<div class="name">{esc(r["category"])}</div>'
            f'<div class="track"><div class="bar" style="width:{pct:.1f}%"></div></div>'
            f'<div class="num">{esc(fmt(v))}{esc(unit)} ESTIMATE</div>'
            "</div>"
        )
        if highlights:
            cal = highlight_callout(highlights.get(r["category"]))
            if cal:
                out.append(cal)
    out.append("</div>")
    return "\n".join(out)


def series_chart(title, points, fmt, unit):
    """Plain div bars in the given (chronological) order; points = [(label, value)]."""
    mx = max([float(v) for _, v in points] or [0])
    out = [f'<div class="card" style="margin-top:20px"><h2>{esc(title)} (ESTIMATE)</h2>']
    for label, v in points:
        v = float(v)
        pct = (v / mx * 100.0) if mx > 0 else 0.0
        out.append(
            '<div class="row">'
            f'<div class="name">{esc(label)}</div>'
            f'<div class="track"><div class="bar" style="width:{pct:.1f}%"></div></div>'
            f'<div class="num">{esc(fmt(v))}{esc(unit)} ESTIMATE</div>'
            "</div>"
        )
    out.append("</div>")
    return "\n".join(out)


NEW_KEYS = ("narrative_paragraph", "confidence_mix", "monthly_trend", "history")


def monthly_block(s):
    if "monthly_trend" not in s:
        return []
    mt = s.get("monthly_trend") or []
    status = str(s.get("monthly_trend_status", ""))
    if not mt:
        return ['<div class="card" style="margin-top:20px"><h2>Assisted hours by month (ESTIMATE)</h2>'
                '<div class="note">Task dates are unknown, so the monthly chart is skipped.</div></div>']
    out = [series_chart("Assisted hours by month", [(m["month"], m["mid_hours"]) for m in mt], fmt_h, " h")]
    if status.startswith("partial"):
        out.append(f'<div class="note">{esc(status)}.</div>')
    return out


def history_block(s):
    if "history" not in s:
        return []
    hist = s.get("history") or []
    status = str(s.get("history_status", ""))
    if len(hist) >= 2:
        out = [series_chart("Mid assisted hours by run date",
                            [(h["run_date"], h["mid_hours"]) for h in hist], fmt_h, " h")]
    else:
        out = ['<div class="note" style="margin-top:12px">Run history: the trend across runs '
               'appears once 2 or more runs are recorded.</div>']
    if status.startswith("skipped") or status.startswith("not saved"):
        out.append(f'<div class="note">Run history {esc(status)}.</div>')
    return out


def render(s):
    cats = {c["category"]: c for c in s.get("categories", [])}
    unknown = set(cats) - set(CATEGORIES)
    if unknown:
        raise SystemExit(f"Unknown categories in summary: {sorted(unknown)}")
    rows = []
    for name in CATEGORIES:
        c = cats.get(name, {})
        rows.append({"category": name,
                     "tasks": int(c.get("tasks", 0)),
                     "mid_hours": float(c.get("mid_hours", 0.0))})
    # Consistency check: per-category totals must match the headline numbers.
    if sum(r["tasks"] for r in rows) != int(s["one_off_tasks"]):
        raise SystemExit("Category task counts do not sum to one_off_tasks")
    if abs(sum(r["mid_hours"] for r in rows) - float(s["mid_hours"])) > 0.05:
        raise SystemExit("Category Mid hours do not sum to mid_hours")

    cov = s["coverage"]
    user = esc(s["user"])
    extended = any(k in s for k in NEW_KEYS)
    hl = {c["category"]: c.get("highlights") for c in s.get("categories", [])} if extended else None
    badge = []
    if isinstance(s.get("confidence_mix"), dict) and s["confidence_mix"].get("line"):
        badge = [f'<div class="badge">{esc(s["confidence_mix"]["line"])} (classification, ESTIMATE)</div>']
    narr = []
    if s.get("narrative_paragraph"):
        narr = ['<div class="narr"><h2>Copy-paste summary (ESTIMATE)</h2>'
                f'{esc(s["narrative_paragraph"])}</div>']
    parts = [
        "<!DOCTYPE html>",
        '<html lang="en"><head><meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        f"<title>Cowork Value ESTIMATE - {user}</title>",
        f"<style>{CSS}{EXTRA_CSS if extended else ''}</style></head><body><div class=\"wrap\">",
        '<div class="hero">',
        "<h1>Cowork Value ESTIMATE</h1>",
        f'<div class="sub">{user} &middot; run {esc(s["run_date"])}</div>',
        '<div class="kpis">',
        f'<div class="kpi"><div class="lab">Mid ESTIMATE</div><div class="val">'
        f'~{esc(fmt_h(s["mid_hours"]))} h &middot; ~{esc(fmt_d(s["mid_dollars"]))}</div></div>',
        f'<div class="kpi"><div class="lab">Low floor ESTIMATE</div><div class="val">'
        f'{esc(fmt_h(s["low_hours"]))} h &middot; {esc(fmt_d(s["low_dollars"]))}</div></div>',
        f'<div class="kpi"><div class="lab">One-off tasks scored</div><div class="val">'
        f'{int(s["one_off_tasks"])}</div></div>',
        "</div>",
        f'<div class="cov">Coverage: {int(cov["rows"])} tasks from {esc(cov["source"])}, '
        f'{esc(cov["date_range"])}. History not in the input (incl. deleted/renamed task '
        "folders) is not counted."
        + (f" OneDrive read {esc(s['discovery'].get('completeness', ''))} "
           f"(fingerprint {esc(s['discovery'].get('fingerprint', ''))})." if s.get("discovery") else "")
        + "</div>",
        *badge,
        "</div>",
        *narr,
        '<div class="charts">',
        bar_chart("Tasks by category", rows, "tasks", lambda v: f"{int(v)}", " tasks"),
        bar_chart("Assisted hours by category (Mid)", rows, "mid_hours", fmt_h, " h", hl),
        "</div>",
        *monthly_block(s),
        *history_block(s),
        '<div class="card" style="margin-top:20px"><h2>Not scored (ESTIMATE scope)</h2>',
        "<table><tr><th>Item</th><th>Count</th></tr>",
        f'<tr><td>Recurring / automation runs excluded</td><td>{int(s["recurring_excluded"])}</td></tr>',
        *([f'<tr><td>&nbsp;&nbsp;of which unconfirmed (repeated or untitled, no matching trigger)</td>'
           f'<td>{int(s["recurring_unconfirmed"])}</td></tr>'] if s.get("recurring_unconfirmed") else []),
        f'<tr><td>Excluded (failed/cancelled, no outcome)</td><td>{int(s["no_outcome_excluded"])}</td></tr>',
        *([f'<tr><td>Cowork value reporting runs (never counted)</td>'
           f'<td>{int(s["self_runs_excluded"])}</td></tr>'] if s.get("self_runs_excluded") else []),
        "</table></div>",
        '<div class="foot"><span class="tag">ESTIMATE</span> &mdash; every figure is an '
        "estimate from effort bands, not billed, measured or realized savings. Bands: "
        f"{esc(BANDS_SOURCE)}; ${RATE_PER_HOUR:,.0f}/hr loaded rate. "
        "Bar widths are a percentage of each chart's largest value.</div>",
        "</div></body></html>",
    ]
    return "\n".join(parts)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--summary", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    with open(a.summary, encoding="utf-8") as f:
        s = json.load(f)
    doc = render(s)
    with open(a.out, "w", encoding="utf-8") as f:
        f.write(doc)
    print(a.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
