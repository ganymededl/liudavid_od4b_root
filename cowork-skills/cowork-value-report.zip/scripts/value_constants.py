#!/usr/bin/env python3
"""Single source of truth for the Cowork Value ESTIMATE constants and helpers.

Imported by build_value_summary.py, enrich_value_summary.py, render_value_html.py
and build_value_xlsx.py. Change bands, rate or source name HERE only.
The slugify() rule is duplicated verbatim in cowork-net-value/scripts/net_value.py;
keep the two copies identical.
"""
import re
import unicodedata

RATE_PER_HOUR = 72.0

# Version of the title-judgment rubric (category table + title_category/title_explicit
# rules in SKILL.md Step 3). Bump it whenever that rubric changes: every cached title
# judgment from an older version is then sent back to the model once.
RUBRIC_VERSION = "title-rubric-v1-2026-11-23"
CACHE_SCHEMA = 1
BANDS_SOURCE = "Cowork Value Methodology v4"

# (category, low, mid, high) minutes per task
EFFORT_BANDS = [
    ("Analysis & Research", 30, 67, 92),
    ("Document & content creation", 12, 24, 42),
    ("Email workflows", 3, 7, 12),
    ("Meeting workflows", 12, 31, 45),
    ("Communication workflows", 2, 4, 6),
    ("Specialized workflows", 10, 25, 40),
    ("Write or debug code", 30, 56, 96),
    ("General assistance/Other", 2, 5, 8),
]
BANDS = {c: {"low": lo, "mid": mi, "high": hi} for c, lo, mi, hi in EFFORT_BANDS}

# Display order used by the HTML and XLSX.
CATEGORIES = [
    "Analysis & Research",
    "Document & content creation",
    "Write or debug code",
    "Specialized workflows",
    "Email workflows",
    "Meeting workflows",
    "Communication workflows",
    "General assistance/Other",
]

CSV_COLUMNS = ["user", "task_title", "created_date", "state", "outcome_summary",
               "recurring_flag", "category", "classification_confidence",
               "low_minutes", "mid_minutes", "high_minutes"]

# Text cells that start with one of these are prefixed with ' so Excel never
# evaluates them as formulas when the CSV is opened (CSV/formula injection).
FORMULA_LEADS = ("=", "+", "-", "@", "\t", "\r")


def slugify(name):
    """Display name -> file-name slug. 'Jose O'Brien' (accents folded) -> 'jose-obrien'."""
    s = unicodedata.normalize("NFKD", str(name or "")).encode("ascii", "ignore").decode("ascii")
    s = re.sub(r"['\u2019`]", "", s.lower())
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s or "user"


def safe_text(v):
    """Neutralise spreadsheet formula leads in a text cell (idempotent)."""
    t = "" if v is None else str(v)
    return "'" + t if t.startswith(FORMULA_LEADS) else t
