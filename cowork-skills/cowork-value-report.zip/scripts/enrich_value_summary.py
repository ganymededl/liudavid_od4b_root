#!/usr/bin/env python3
"""Add the derived fields to the Cowork Value ESTIMATE summary JSON (compute once).

Standard library only. Reads working/cowork_value_summary.json (written by the
build_value_summary.py build step, which must include the `items` list -- the exact rows the
CSV is written from) and adds, in place:

  categories[i].highlights   up to 3 real scored one-off tasks per active category
  categories[i].low/mid/high_dollars, high_hours, top-level high_hours/high_dollars
                             (only if the Step 4 run did not already write them)
  monthly_trend              [{month, tasks, mid_hours, by_category}] (YYYY-MM)
  monthly_trend_status       "ok" | "unknown dates" | "partial: N undated"
  confidence_mix             {High, Medium, Low (percent, sum 100), counts, line}
  narrative_paragraph        deterministic first-person ESTIMATE paragraph
  effort_bands, rate_per_hour, bands_source
  history, history_status    cross-run trend (see --history-* options)

The chat response, CSV, HTML (render_value_html.py) and XLSX (build_value_xlsx.py)
all read these fields; nothing is recomputed downstream.

Usage:
  python enrich_value_summary.py --summary working/cowork_value_summary.json \
      [--history-in <downloaded history json>] [--history-new] \
      [--history-skip "reason"] [--history-out <local history json>]
  python enrich_value_summary.py --summary ... --set-history-status "text"

History options (exactly one of --history-in / --history-new / --history-skip):
  --history-in PATH   prior history file downloaded from OneDrive; merged with
                      today's entry (same run_date overwrites) and written to
                      --history-out (default: PATH itself, for in-place upload)
  --history-new       no history file exists yet (first run); writes a new one
  --history-skip WHY  history unreadable/unavailable; only today's entry is
                      shown, nothing is written
`items` row keys = CSV columns: user, task_title, created_date, state,
outcome_summary, recurring_flag, category, classification_confidence,
low_minutes, mid_minutes, high_minutes (minutes blank for unscored rows).
"""
import argparse
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from value_constants import BANDS_SOURCE, EFFORT_BANDS, RATE_PER_HOUR as RATE  # noqa: E402

CONF_ORDER = {"High": 0, "Medium": 1, "Low": 2}
SNIPPET_MAX = 120


def fmt_h(x):
    return f"{float(x):,.1f}"


def fmt_d(x):
    return f"${float(x):,.0f}"


def is_scored(r):
    return str(r.get("mid_minutes", "")).strip() not in ("", "None")


def as_bool(v):
    return str(v).strip().lower() in ("true", "1", "yes", "y", "recurring")


def scored_items(s):
    return [r for r in s.get("items", []) if is_scored(r) and not as_bool(r.get("recurring_flag"))]


def month_of(d):
    m = re.match(r"\s*(\d{4})-(\d{2})", str(d or ""))
    return f"{m.group(1)}-{m.group(2)}" if m else None


def snippet(text):
    t = " ".join(str(text or "").split())
    return t if len(t) <= SNIPPET_MAX else t[: SNIPPET_MAX - 1].rstrip() + "\u2026"


def pick_highlights(rows):
    """Up to 3 real rows: High confidence first, then more descriptive titles."""
    seen, out = set(), []
    def key(r):
        t = str(r.get("task_title", "")).strip()
        return (CONF_ORDER.get(str(r.get("classification_confidence", "")).strip().title(), 3),
                -len(t.split()), -len(t), t.lower())
    for r in sorted(rows, key=key):
        t = str(r.get("task_title", "")).strip()
        if not t or t.lower() in seen:
            continue
        seen.add(t.lower())
        out.append({"task_title": t,
                    "outcome_summary": snippet(r.get("outcome_summary", "")),
                    "classification_confidence": str(r.get("classification_confidence", "")).strip(),
                    "created_date": str(r.get("created_date", "")).strip()})
        if len(out) == 3:
            break
    return out


def pct_largest_remainder(counts):
    total = sum(counts.values())
    if total == 0:
        return {k: 0 for k in counts}
    raw = {k: v * 100.0 / total for k, v in counts.items()}
    fl = {k: int(raw[k]) for k in raw}
    rest = 100 - sum(fl.values())
    for k in sorted(raw, key=lambda k: (-(raw[k] - fl[k]), CONF_ORDER[k]))[:rest]:
        fl[k] += 1
    return fl


def narrative(s, cats):
    n = int(s["one_off_tasks"])
    lead = ("Based on an ESTIMATE from effort bands (not billed or measured savings), ")
    if n == 0:
        return (lead + "no one-off Cowork tasks could be scored in this run, so no assisted hours "
                "are estimated. Figures would be based on the " + BANDS_SOURCE + " at a $72/hr loaded rate.")
    sents = [lead + f"my Cowork use across {n} one-off task{'s' if n != 1 else ''} represents about "
             f"{fmt_h(s['mid_hours'])} assisted hours (~{fmt_d(s['mid_dollars'])}) at the Mid band, "
             f"with a defensible floor of {fmt_h(s['low_hours'])} hours ({fmt_d(s['low_dollars'])})."]
    top = [c for c in sorted(cats, key=lambda c: (-float(c.get("mid_hours", 0)), c["category"]))
           if int(c.get("tasks", 0)) > 0][:2]
    part = [f"{c['category']} ({fmt_h(c['mid_hours'])} h across {int(c['tasks'])} "
            f"task{'s' if int(c['tasks']) != 1 else ''})" for c in top]
    if part:
        sents.append("The largest share came from " + " and ".join(part) + ".")
    dr = str(s.get("coverage", {}).get("date_range", "unknown"))
    if dr and dr.lower() != "unknown":
        sents.append(f"These tasks span {dr}.")
    sents.append("All figures are ESTIMATES based on the " + BANDS_SOURCE + " at a $72/hr loaded rate.")
    return " ".join(sents)


def top_category(cats):
    act = [c for c in cats if int(c.get("tasks", 0)) > 0]
    if not act:
        return ""
    return sorted(act, key=lambda c: (-float(c.get("mid_hours", 0)), c["category"]))[0]["category"]


def history_entry(s, cats):
    return {"run_date": s["run_date"], "mid_hours": round(float(s["mid_hours"]), 1),
            "mid_dollars": round(float(s["mid_dollars"]), 0),
            "tasks_scored": int(s["one_off_tasks"]), "top_category": top_category(cats)}


def load_history(path):
    with open(path, encoding="utf-8-sig") as f:
        data = json.load(f)
    entries = data.get("entries", data) if isinstance(data, dict) else data
    if not isinstance(entries, list):
        raise ValueError("history file is not a list of entries")
    return [e for e in entries if isinstance(e, dict) and e.get("run_date")]


def enrich(s, args):
    if "items" not in s:
        raise SystemExit("summary JSON has no `items` (the CSV row list); write it in the Step 4 run")
    cats = s.get("categories", [])
    by_cat = {}
    for r in scored_items(s):
        by_cat.setdefault(r.get("category", ""), []).append(r)
    hi_tot = 0.0
    for c in cats:
        c.setdefault("high_hours", 0.0)
        for b in ("low", "mid", "high"):
            c.setdefault(f"{b}_dollars", round(float(c.get(f"{b}_hours", 0.0)) * RATE, 2))
        hi_tot += float(c["high_hours"])
        c["highlights"] = pick_highlights(by_cat.get(c["category"], [])) if int(c.get("tasks", 0)) > 0 else []
    s.setdefault("high_hours", round(hi_tot, 2))
    s.setdefault("high_dollars", round(float(s["high_hours"]) * RATE, 2))

    # Monthly trend (scored one-off tasks only).
    months, undated = {}, 0
    for r in scored_items(s):
        m = month_of(r.get("created_date"))
        if not m:
            undated += 1
            continue
        e = months.setdefault(m, {"month": m, "tasks": 0, "mid_minutes": 0.0, "by_category": {}})
        mm = float(r["mid_minutes"])
        e["tasks"] += 1
        e["mid_minutes"] += mm
        e["by_category"][r["category"]] = e["by_category"].get(r["category"], 0.0) + mm
    s["monthly_trend"] = [{"month": e["month"], "tasks": e["tasks"],
                           "mid_hours": round(e["mid_minutes"] / 60.0, 2),
                           "by_category": {k: round(v / 60.0, 2) for k, v in sorted(e["by_category"].items())}}
                          for _, e in sorted(months.items())]
    if not s["monthly_trend"]:
        s["monthly_trend_status"] = "unknown dates"
    elif undated:
        s["monthly_trend_status"] = f"partial: {undated} undated task{'s' if undated != 1 else ''} not in the monthly chart"
    else:
        s["monthly_trend_status"] = "ok"

    # Confidence mix.
    counts = {"High": 0, "Medium": 0, "Low": 0}
    for r in scored_items(s):
        k = str(r.get("classification_confidence", "")).strip().title()
        if k in counts:
            counts[k] += 1
    p = pct_largest_remainder(counts)
    s["confidence_mix"] = dict(p, counts=counts,
                               line=(f"Confidence mix: {p['High']}% High \u00b7 {p['Medium']}% Medium \u00b7 {p['Low']}% Low"
                                     if sum(counts.values()) else "Confidence mix: no scored tasks"))

    s["narrative_paragraph"] = narrative(s, cats)
    s["effort_bands"] = [{"category": c, "low_minutes": lo, "mid_minutes": mi, "high_minutes": hi,
                          "source": BANDS_SOURCE} for c, lo, mi, hi in EFFORT_BANDS]
    s["rate_per_hour"] = RATE
    s["bands_source"] = BANDS_SOURCE

    # Cross-run history.
    today = history_entry(s, cats)
    if args.history_skip:
        s["history"] = [today]
        s["history_status"] = f"skipped: {args.history_skip}"
        return None
    prior = []
    if args.history_in:
        try:
            prior = load_history(args.history_in)
        except Exception as e:  # unreadable/corrupt: do not overwrite it
            s["history"] = [today]
            s["history_status"] = f"skipped: history file unreadable ({type(e).__name__})"
            return None
    merged = {e["run_date"]: e for e in prior}
    merged[today["run_date"]] = today
    s["history"] = [merged[k] for k in sorted(merged)]
    s["history_status"] = "pending upload"
    out = args.history_out or args.history_in
    if out:
        with open(out, "w", encoding="utf-8") as f:
            json.dump({"user": s["user"], "entries": s["history"]}, f, indent=2, ensure_ascii=False)
            f.write("\n")
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--summary", required=True)
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--history-in")
    g.add_argument("--history-new", action="store_true")
    g.add_argument("--history-skip")
    g.add_argument("--set-history-status")
    ap.add_argument("--history-out")
    a = ap.parse_args()
    with open(a.summary, encoding="utf-8") as f:
        s = json.load(f)
    if a.set_history_status is not None:
        s["history_status"] = a.set_history_status
        wrote = None
    else:
        if not (a.history_in or a.history_new or a.history_skip):
            a.history_skip = "history not attempted"
        if a.history_new and not a.history_out:
            raise SystemExit("--history-new needs --history-out")
        wrote = enrich(s, a)
    with open(a.summary, "w", encoding="utf-8") as f:
        json.dump(s, f, indent=2, ensure_ascii=False)
    print(json.dumps({"summary": a.summary, "history_file": wrote,
                      "history_status": s.get("history_status")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
