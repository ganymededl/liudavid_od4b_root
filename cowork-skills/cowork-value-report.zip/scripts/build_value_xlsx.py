#!/usr/bin/env python3
"""Build the 4-tab Cowork Value ESTIMATE workbook from the summary JSON.

openpyxl + standard library only; no macros, no formulas, no external links.
Reads only working/cowork_value_summary.json after enrich_value_summary.py ran;
nothing is recomputed here. "Raw Items" is written from the summary's `items`
list -- the same row list the CSV is written from -- and, with --csv, is checked
cell-for-cell against the published CSV.

Usage:
  python build_value_xlsx.py --summary working/cowork_value_summary.json \
      --out working/cowork_value_<user>_<yyyy-mm-dd>.xlsx \
      [--csv working/cowork_value_<user>_<yyyy-mm-dd>.csv]

Exit codes: 0 written; 3 openpyxl unavailable (nothing written -- say so in
the Verdict and skip only the XLSX); 1 data problem (message printed).
"""
import argparse
import csv
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from value_constants import CATEGORIES, CSV_COLUMNS  # noqa: E402


def cell_text(v):
    return "" if v is None else str(v)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--summary", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--csv")
    a = ap.parse_args()
    try:
        from openpyxl import Workbook
        from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter
    except ImportError:
        print("XLSX skipped: openpyxl is not available in this environment.")
        return 3

    with open(a.summary, encoding="utf-8") as f:
        s = json.load(f)
    for k in ("items", "effort_bands", "monthly_trend"):
        if k not in s:
            print(f"summary JSON lacks `{k}`; run enrich_value_summary.py first")
            return 1
    cats = {c["category"]: c for c in s.get("categories", [])}
    if sum(int(c.get("tasks", 0)) for c in cats.values()) != int(s["one_off_tasks"]):
        print("Category task counts do not sum to one_off_tasks")
        return 1
    if abs(sum(float(c.get("mid_hours", 0)) for c in cats.values()) - float(s["mid_hours"])) > 0.05:
        print("Category Mid hours do not sum to mid_hours")
        return 1

    head_fill = PatternFill("solid", fgColor="DEECF9")
    head_font = Font(bold=True, color="005A9E")
    title_font = Font(bold=True, size=14, color="005A9E")
    bold = Font(bold=True)

    def put(ws, r, c, v, fmt=None, font=None):
        if isinstance(v, str):
            v = ILLEGAL_CHARACTERS_RE.sub("", v)
        cell = ws.cell(row=r, column=c, value=v)
        if isinstance(v, str) and v.startswith("="):
            cell.data_type = "s"  # text, never a formula
        if fmt:
            cell.number_format = fmt
        if font:
            cell.font = font
        return cell

    def header(ws, r, labels):
        for i, lab in enumerate(labels, 1):
            c = put(ws, r, i, lab, font=head_font)
            c.fill = head_fill
            c.alignment = Alignment(wrap_text=True, vertical="top")

    def widths(ws, w):
        for i, x in enumerate(w, 1):
            ws.column_dimensions[get_column_letter(i)].width = x

    H, D = "#,##0.0", "$#,##0"
    wb = Workbook()

    # --- Summary -----------------------------------------------------------
    ws = wb.active
    ws.title = "Summary"
    put(ws, 1, 1, f"Cowork Value ESTIMATE \u2014 {s['user']} (run {s['run_date']})", font=title_font)
    put(ws, 2, 1, "Every figure is an ESTIMATE from effort bands, not billed, measured or realized savings.")
    cov = s.get("coverage", {})
    put(ws, 3, 1, f"Coverage: {cov.get('rows', '')} tasks from {cov.get('source', '')}, "
                  f"{cov.get('date_range', '')}. History not in the input is not counted."
                  + (f" OneDrive read {s['discovery'].get('completeness', '')} "
                     f"(fingerprint {s['discovery'].get('fingerprint', '')})." if s.get("discovery") else ""))
    if isinstance(s.get("confidence_mix"), dict):
        put(ws, 4, 1, s["confidence_mix"].get("line", ""))
    cols = ["Category", "Tasks", "Low hours (ESTIMATE)", "Mid hours (ESTIMATE)", "High hours (ESTIMATE)",
            "Low $ (ESTIMATE)", "Mid $ (ESTIMATE)", "High $ (ESTIMATE)"]
    header(ws, 6, cols)
    r = 7
    for name in CATEGORIES:
        c = cats.get(name, {})
        vals = [name, int(c.get("tasks", 0)), c.get("low_hours", 0), c.get("mid_hours", 0), c.get("high_hours", 0),
                c.get("low_dollars", 0), c.get("mid_dollars", 0), c.get("high_dollars", 0)]
        for i, v in enumerate(vals, 1):
            put(ws, r, i, v, fmt=(H if i in (3, 4, 5) else D if i > 5 else None))
        r += 1
    tot = ["Total (ESTIMATE)", int(s["one_off_tasks"]), s["low_hours"], s["mid_hours"], s.get("high_hours", 0),
           s["low_dollars"], s["mid_dollars"], s.get("high_dollars", 0)]
    for i, v in enumerate(tot, 1):
        put(ws, r, i, v, fmt=(H if i in (3, 4, 5) else D if i > 5 else None), font=bold)
    r += 2
    tail = [("Recurring / automation runs excluded", int(s.get("recurring_excluded", 0)))]
    if s.get("recurring_unconfirmed"):
        tail.append(("  of which unconfirmed (repeated or untitled, no matching trigger)", int(s["recurring_unconfirmed"])))
    tail.append(("Excluded (failed/cancelled, no outcome)", int(s.get("no_outcome_excluded", 0))))
    if s.get("self_runs_excluded"):
        tail.append(("Cowork value reporting runs (never counted)", int(s["self_runs_excluded"])))
    for i, (label, val) in enumerate(tail):
        put(ws, r + i, 1, label)
        put(ws, r + i, 2, val)
    widths(ws, [34, 10, 16, 16, 16, 16, 16, 16])
    ws.freeze_panes = "A7"

    # --- By Category -------------------------------------------------------
    ws = wb.create_sheet("By Category")
    put(ws, 1, 1, "By category and month \u2014 ESTIMATE", font=title_font)
    header(ws, 3, cols + ["Representative examples (real task titles)"])
    r = 4
    for name in CATEGORIES:
        c = cats.get(name, {})
        vals = [name, int(c.get("tasks", 0)), c.get("low_hours", 0), c.get("mid_hours", 0), c.get("high_hours", 0),
                c.get("low_dollars", 0), c.get("mid_dollars", 0), c.get("high_dollars", 0),
                "; ".join(h["task_title"] for h in c.get("highlights", []) or [])]
        for i, v in enumerate(vals, 1):
            put(ws, r, i, v, fmt=(H if i in (3, 4, 5) else D if 5 < i < 9 else None))
        r += 1
    r += 1
    put(ws, r, 1, "Monthly pivot \u2014 Mid assisted hours (ESTIMATE) by created month", font=bold)
    r += 1
    mt = s.get("monthly_trend") or []
    if not mt:
        put(ws, r, 1, "Task dates are unknown, so there is no monthly pivot.")
    else:
        header(ws, r, ["Month", "Tasks", "Mid hours (ESTIMATE)"] + [f"{n} (Mid h, ESTIMATE)" for n in CATEGORIES])
        for m in mt:
            r += 1
            put(ws, r, 1, m["month"])
            put(ws, r, 2, int(m["tasks"]))
            put(ws, r, 3, m["mid_hours"], fmt=H)
            for j, n in enumerate(CATEGORIES, 4):
                put(ws, r, j, (m.get("by_category") or {}).get(n, 0), fmt=H)
        status = str(s.get("monthly_trend_status", ""))
        if status.startswith("partial"):
            put(ws, r + 1, 1, status)
    widths(ws, [34, 10, 16, 16, 16, 16, 16, 16, 60] + [16] * 3)

    # --- Raw Items (identical to CSV) --------------------------------------
    ws = wb.create_sheet("Raw Items")
    header(ws, 1, CSV_COLUMNS)
    for i, row in enumerate(s["items"], 2):
        for j, k in enumerate(CSV_COLUMNS, 1):
            v = row.get(k, "")
            put(ws, i, j, None if v == "" or v is None else v)
    widths(ws, [20, 48, 14, 12, 48, 12, 28, 14, 12, 12, 12])
    ws.freeze_panes = "A2"

    # --- Assumptions & Sources --------------------------------------------
    ws = wb.create_sheet("Assumptions & Sources")
    put(ws, 1, 1, "Effort bands (minutes per task) used for every ESTIMATE", font=title_font)
    header(ws, 3, ["Category", "Low minutes", "Mid minutes", "High minutes", "Primary source"])
    for i, b in enumerate(s["effort_bands"], 4):
        for j, k in enumerate(["category", "low_minutes", "mid_minutes", "high_minutes", "source"], 1):
            put(ws, i, j, b[k])
    rr = 4 + len(s["effort_bands"]) + 1
    put(ws, rr, 1, "Loaded labor rate ($/hr)")
    put(ws, rr, 2, s.get("rate_per_hour", 72), fmt="$#,##0")
    put(ws, rr + 1, 1, "Assisted hours = sum(minutes) / 60; $ = hours \u00d7 rate. "
                       "Recurring automation and no-outcome tasks are not scored.")
    widths(ws, [34, 14, 14, 14, 48])

    # --- Changes vs last run (from the classification cache's last_run) -----
    rc = s.get("run_comparison")
    if isinstance(rc, dict):
        ws = wb.create_sheet("Changes vs Last Run")
        put(ws, 1, 1, "Changes vs last run \u2014 ESTIMATE", font=title_font)
        put(ws, 2, 1, s.get("repeatability", ""))
        if not rc.get("previous_run_date"):
            put(ws, 4, 1, "No previous run recorded; this run is the baseline.")
        else:
            d = rc.get("delta", {})
            put(ws, 3, 1, f"Previous run: {rc['previous_run_date']}. Added {rc['counts']['added']}, "
                          f"removed {rc['counts']['removed']}, changed {rc['counts']['changed']}, "
                          f"unchanged {rc['counts']['unchanged']}. Mid change: {d.get('mid_minutes', 0)} min "
                          f"(${d.get('mid_dollars', 0):,.2f} ESTIMATE).")
            header(ws, 5, ["Change", "Task folder id", "Task title", "Before", "After",
                           "Mid minutes delta (ESTIMATE)", "Why"])
            r = 6
            for x in rc.get("added", []):
                vals = ["Added", x["id"], x["title"], "", f"{x['status']} {x['category']} {x['mid_minutes']} min",
                        x["mid_minutes"], x["why"]]
                for j, v in enumerate(vals, 1):
                    put(ws, r, j, v)
                r += 1
            for x in rc.get("removed", []):
                vals = ["Removed", x["id"], x["title"], f"{x['was']} {x['category']} {x['mid_minutes']} min", "",
                        -int(x["mid_minutes"]), x["why"]]
                for j, v in enumerate(vals, 1):
                    put(ws, r, j, v)
                r += 1
            for x in rc.get("changed", []):
                vals = ["Changed", x["id"], x["title"], x["before"], x["after"], x["mid_minutes_delta"], x["why"]]
                for j, v in enumerate(vals, 1):
                    put(ws, r, j, v)
                r += 1
            if r == 6:
                put(ws, 6, 1, "No task changed since the previous run.")
        widths(ws, [12, 28, 40, 40, 40, 16, 48])

    # Raw Items identity check against the CSV, when given.
    if a.csv:
        with open(a.csv, encoding="utf-8-sig", newline="") as f:
            rows = list(csv.reader(f))
        if rows[0] != CSV_COLUMNS:
            print("CSV header differs from the Raw Items header")
            return 1
        want = [[ILLEGAL_CHARACTERS_RE.sub("", cell_text(it.get(k, ""))) for k in CSV_COLUMNS] for it in s["items"]]
        got = [[ILLEGAL_CHARACTERS_RE.sub("", x) for x in r] for r in rows[1:]]
        if want != got:
            print("Raw Items rows differ from the CSV rows; write both from summary['items']")
            return 1

    wb.save(a.out)
    print(a.out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
