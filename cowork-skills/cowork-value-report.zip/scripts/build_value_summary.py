#!/usr/bin/env python3
"""Deterministic core of the Cowork Value ESTIMATE (Steps 1-4). Standard library only.

The model does ONE judgement per task -- what the title says (category or none,
and whether the verb is explicit). Everything else is fixed code here, so the
same inputs and classifications always give the same numbers.

Runs of the value-reporting skills themselves are removed before anything else, so
rerunning the report never adds savings by itself: the current task's folder
(--exclude-ids), folders whose output/ holds only cowork_value_* / cowork_net_value_*
files, and trigger-phrase titles ("run my Cowork value") with no other output. A title
alone never removes a task that produced other work; report artifacts in a mixed
folder are ignored as evidence. --include-unconfirmed scores repeated/untitled tasks
that match no trigger, when the user asks for that.

Sub-commands
  slug     --name "<display name>"
           Prints {"slug": "..."}; the same rule as cowork-net-value.

  prepare  --tasks <tasks.json> --source "<source label>" --today <yyyy-mm-dd>
           [--tz <IANA zone>] [--triggers <triggers.json>] --out working/value_tasks_prepared.json
           Humanizes titles, converts created dates to the user's LOCAL date,
           derives state/outcome, reads file-extension signals, flags recurring
           automation, and lists the one-off tasks the model must classify
           (`to_classify`).

  build    --prepared working/value_tasks_prepared.json --classifications <cls.json>
           --user "<display name>" --summary-out working/cowork_value_summary.json
           --csv-out working/cowork_value_<slug>_<yyyy-mm-dd>.csv
           Validates the classifications, decides final category + confidence,
           applies the effort bands, and writes the summary JSON (with `items`)
           and the itemized CSV (UTF-8 BOM, formula-safe). Prints the headline JSON.

tasks.json -- a list, one object per task:
  {"id": "...", "name": "<folder name>"  (OneDrive)  or  "title": "<task title>" (supplied list),
   "created": "<ISO datetime, date, or empty>",
   "input_files": ["a.docx", ...], "output_files": ["b.pptx", ...],
   "state": "<optional, supplied lists only>", "outcome_summary": "<optional>"}

triggers.json -- optional list from GetEventTriggers / GetScheduledPrompts:
  [{"name": "...", "state": "...", "fire_count": 12, "last_fired_at": "..."}]

classifications.json -- object keyed by task id, one entry per id in `to_classify`:
  {"<id>": {"title_category": "<one of the 8 categories>" | null,
            "title_explicit": true | false,
            "rationale": "<one line>"}}
  title_category = what the TITLE alone indicates (null when the title is vague).
  title_explicit = the title has a clear action verb ("draft", "analyze", "fix").

Exit codes: 0 ok; 2 bad input (message printed as JSON).
"""
import argparse
import csv
import datetime as dt
import hashlib
import json
import os
import re
import sys
import unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from value_constants import (BANDS, BANDS_SOURCE, CACHE_SCHEMA, CATEGORIES,  # noqa: E402
                             CSV_COLUMNS, RATE_PER_HOUR, RUBRIC_VERSION, safe_text, slugify)

EXT_CATEGORY = {}
for _cat, _exts in [
    ("Write or debug code", ".ps1 .psm1 .py .js .ts .sh .sql .kql"),
    ("Document & content creation", ".pptx .docx .pdf .md .html .htm"),
    ("Analysis & Research", ".xlsx .csv .pbit .pbix .json"),
    ("Meeting workflows", ".vtt"),
    ("Email workflows", ".msg .eml"),
]:
    for _e in _exts.split():
        EXT_CATEGORY[_e] = _cat

RECUR_MIN_REPEATS = 5
FAILED_STATES = {"failed", "cancelled", "canceled", "error", "stopped"}
OUTCOME_MAX = 200

_TRAIL = re.compile(
    r"[-_ .]+(?:\d{4}-?\d{2}-?\d{2}(?:[t_ -]?\d{2}[-:]?\d{2}(?:[-:]?\d{2})?)?z?"   # date / datetime
    r"|\d{1,2}[-:]?\d{2}(?:[-:]?\d{2})?"                                          # time
    r"|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"              # guid
    r"|(?=[0-9a-f]*\d)[0-9a-f]{6,}"                                               # hex id with a digit
    r"|\d+)$", re.IGNORECASE)
# Folders produced by the value-reporting skills themselves (never counted as savings).
_SELF_OUTPUT = re.compile(r"^(?:cowork_(?:net_)?value_.+\.(?:csv|html|xlsx|json)|cowork_value_summary\.json)$",
                          re.IGNORECASE)
# Trigger phrases of the two reporting skills, matched at the START of a normalized title only,
# so ordinary work such as "draft cowork value deck" is still counted.
_SELF_TITLE = re.compile(r"^(?:run my cowork value|net my cowork value|cowork value report|"
                         r"cowork net (?:value|savings)|cowork value minus credits|"
                         r"estimate my cowork hours saved|reconstruct my use cases|"
                         r"what did cowork actually cost)\b")
_GENERIC = re.compile(r"^(?:untitled|new[-_ ]?task|task)(?:[-_ ][\d\-_: tz]*)?$|^[\d\-_: tz]+$",
                      re.IGNORECASE)


def fail(msg):
    print(json.dumps({"ok": False, "error": msg}))
    sys.exit(2)


def load_json(path, label):
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception as e:
        fail(f"could not read {label} ({path}): {e}")


def humanize(name):
    t = str(name or "").strip()
    prev = None
    while prev != t:
        prev = t
        t = _TRAIL.sub("", t)
    t = re.sub(r"[-_]+", " ", t)
    t = " ".join(t.split())
    return t or " ".join(re.sub(r"[-_]+", " ", str(name or "")).split())


def norm_title(t):
    """Unicode-aware: keeps letters in any script, drops digits, punctuation and _."""
    t = str(t or "").casefold()
    t = re.sub(r"[\W\d_]+", " ", t)
    return " ".join(t.split())


def local_date(value, tz):
    """User-local yyyy-mm-dd, "" when blank, or None when not a real date (e.g. 2026-11-99)."""
    v = str(value or "").strip()
    if not v:
        return ""
    if re.match(r"^\d{4}-\d{2}-\d{2}$", v):
        try:
            return dt.date.fromisoformat(v).isoformat()
        except ValueError:
            return None
    try:
        d = dt.datetime.fromisoformat(v.replace("Z", "+00:00"))
    except ValueError:
        return None
    if d.tzinfo is None:
        d = d.replace(tzinfo=dt.timezone.utc)
    if tz:
        from zoneinfo import ZoneInfo
        d = d.astimezone(ZoneInfo(tz))
    else:
        d = d.astimezone(dt.timezone.utc)
    return d.strftime("%Y-%m-%d")


def ext_of(f):
    return os.path.splitext(str(f).strip().lower())[1]


def dominant(files):
    """All categories tied for the most files (fixed category order), or []."""
    counts = {}
    for f in files or []:
        c = EXT_CATEGORY.get(ext_of(f))
        if c:
            counts[c] = counts.get(c, 0) + 1
    if not counts:
        return []
    top = max(counts.values())
    return sorted((c for c in counts if counts[c] == top), key=CATEGORIES.index)


def title_fp(title):
    """Fingerprint of the exact title text the model judges (NFC, whitespace-collapsed)."""
    t = " ".join(unicodedata.normalize("NFC", str(title or "")).split())
    return hashlib.sha256(t.encode("utf-8")).hexdigest()[:16]


def load_cache(a):
    """Return (cache dict or None, state, detail)."""
    if a.cache_skip:
        return None, "unavailable", a.cache_skip
    if not a.cache_in:
        return {"schema": CACHE_SCHEMA, "entries": {}, "last_run": None}, "new", "no cache yet (first run)"
    try:
        with open(a.cache_in, encoding="utf-8-sig") as f:
            c = json.load(f)
        if not isinstance(c, dict) or not isinstance(c.get("entries"), dict):
            raise ValueError("not a classification cache")
        if int(c.get("schema", 0)) != CACHE_SCHEMA:
            raise ValueError(f"cache schema {c.get('schema')} != {CACHE_SCHEMA}")
        c.setdefault("last_run", None)
        return c, "loaded", f"{len(c['entries'])} cached title judgment(s)"
    except Exception as e:  # unreadable/corrupt: do not trust it, do not overwrite it
        return None, "unavailable", f"cache unreadable ({type(e).__name__}: {e})"


# ---------------------------------------------------------------- prepare
def cmd_prepare(a):
    tasks = load_json(a.tasks, "tasks")
    if not isinstance(tasks, list):
        fail("tasks JSON must be a list")
    if a.tz:
        try:
            from zoneinfo import ZoneInfo
            ZoneInfo(a.tz)
        except Exception:
            fail(f"unknown time zone: {a.tz}")
    discovery = None
    if a.discovery:
        discovery = load_json(a.discovery, "discovery report")
        if not discovery.get("complete"):
            fail("discovery report is not complete -- an incomplete OneDrive read is never scored")
    elif any(t.get("name") and not t.get("title") for t in tasks):
        fail("OneDrive folder tasks need --discovery <discovery_report.json> from discover_tasks.py")
    triggers = load_json(a.triggers, "triggers") if a.triggers else []
    trig_norm = {norm_title(t.get("name")): t for t in triggers if norm_title(t.get("name"))}

    rows, seen, invalid_dates = [], set(), []
    for i, t in enumerate(tasks):
        tid = str(t.get("id") or f"row{i + 1}")
        if tid in seen:
            fail(f"duplicate task id: {tid}")
        seen.add(tid)
        from_folder = bool(t.get("name")) and not t.get("title")
        raw = t.get("name") if from_folder else t.get("title")
        if not str(raw or "").strip():
            fail(f"task {tid} has no name/title")
        title = humanize(raw) if from_folder else " ".join(str(raw).split())
        ins = [str(x) for x in t.get("input_files") or []]
        outs = [str(x) for x in t.get("output_files") or []]
        if from_folder:
            state = "completed" if outs else "no output"
            outcome = "; ".join(outs)
        else:
            state = str(t.get("state") or "").strip()
            outcome = str(t.get("outcome_summary") or "").strip()
        if len(outcome) > OUTCOME_MAX:
            outcome = outcome[:OUTCOME_MAX - 1].rstrip() + "\u2026"
        cd = local_date(t.get("created"), a.tz)
        if cd is None:  # never publish an impossible date: blank it and disclose
            invalid_dates.append({"id": tid, "title": title, "created": str(t.get("created"))})
            cd = ""
        elif cd and cd > a.today:
            invalid_dates.append({"id": tid, "title": title, "created": str(t.get("created")),
                                  "reason": "after today"})
            cd = ""
        rows.append({"id": tid, "raw_name": str(raw), "title": title, "_supplied": not from_folder,
                     "created_date": cd,
                     "state": state, "outcome_summary": outcome,
                     "input_files": ins, "output_files": outs,
                     "output_ext_category": dominant(outs), "input_ext_category": dominant(ins)})

    # Deterministic order regardless of how the input was listed or paged.
    rows.sort(key=lambda r: (r["created_date"], r["id"]))

    # Self-exclusion, strongest evidence first:
    #  1. the current task's own folder id (--exclude-ids);
    #  2. every output file is a known report artifact;
    #  3. a report trigger-phrase title AND no output other than report artifacts.
    # A title prefix alone never excludes a task that produced other work.
    self_ids = set(a.exclude_ids or [])
    for r in rows:
        report_outs = [f for f in r["output_files"] if _SELF_OUTPUT.match(os.path.basename(f))]
        other_outs = [f for f in r["output_files"] if not _SELF_OUTPUT.match(os.path.basename(f))]
        if r["id"] in self_ids:
            r["self_run"] = "current task (--exclude-ids)"
        elif report_outs and not other_outs:
            r["self_run"] = "only report artifacts in output/"
        elif not other_outs and _SELF_TITLE.match(norm_title(r["title"])):
            r["self_run"] = "report trigger phrase and no other output"
        else:
            r["self_run"] = ""
        if not r["self_run"] and report_outs:
            # Mixed folder: drop report artifacts so they never act as evidence of work.
            r["output_files"] = other_outs
            r["output_ext_category"] = dominant(other_outs)
            if r["outcome_summary"] and not r.get("_supplied"):
                r["outcome_summary"] = "; ".join(other_outs)
    self_rows = [r for r in rows if r["self_run"]]
    rows = [r for r in rows if not r["self_run"]]

    groups = {}
    for r in rows:
        groups.setdefault(norm_title(r["title"]), []).append(r)
    for r in rows:
        n = norm_title(r["title"])
        basis, confirmed = None, False
        if n and n in trig_norm:
            basis, confirmed = f"matches trigger/schedule '{trig_norm[n].get('name')}'", True
        elif _GENERIC.match(r["raw_name"].strip()) or not n:
            basis = "untitled/date-only name, no matching trigger (unconfirmed automation)"
        elif len(groups[n]) >= RECUR_MIN_REPEATS:
            basis = f"title repeated {len(groups[n])} times, no matching trigger (unconfirmed automation)"
        if basis and not confirmed and a.include_unconfirmed:
            r["included_unconfirmed"] = basis.replace("(unconfirmed automation)", "(counted at the user's request)")
            basis = None
        r["recurring_flag"] = basis is not None
        r["recurring_confirmed"] = confirmed
        r["recurring_basis"] = basis or ""

    rec_groups = {}
    for r in rows:
        if not r["recurring_flag"]:
            continue
        generic = r["recurring_basis"].startswith("untitled")
        key = "__generic__" if generic else norm_title(r["title"])
        g = rec_groups.setdefault(key, {"name": "Untitled / date-only task folders" if generic else r["title"],
                                        "runs": 0, "basis": r["recurring_basis"],
                                        "confirmed": r["recurring_confirmed"]})
        g["runs"] += 1
        t = trig_norm.get(norm_title(r["title"]))
        if t:
            g.update({"trigger_state": t.get("state"), "fire_count": t.get("fire_count"),
                      "last_fired_at": t.get("last_fired_at")})

    # Classification cache: reuse the model's earlier TITLE judgment for an unchanged task.
    # Key = stable OneDrive folder id + fingerprint of the title the model sees + rubric version.
    # Final category, confidence, exclusions and totals are always recomputed from current evidence.
    stable_ids = all(not r["_supplied"] for r in rows) and bool(rows)
    if rows and not stable_ids:
        cache, cstate, cdetail = None, "not used", "supplied task list has no stable OneDrive folder ids"
    else:
        cache, cstate, cdetail = load_cache(a)
    entries = (cache or {}).get("entries", {})
    cached, to_classify = {}, []
    for r in rows:
        r["title_fp"] = title_fp(r["title"])
        if r["recurring_flag"]:
            continue
        e = entries.get(r["id"])
        if e and e.get("title_fp") == r["title_fp"] and e.get("rubric_version") == RUBRIC_VERSION:
            cached[r["id"]] = {k: e[k] for k in ("title_category", "title_explicit", "rationale") if k in e}
            continue
        reason = ("new task" if not e else
                  "title changed" if e.get("title_fp") != r["title_fp"] else "rubric version changed")
        if cache is None:
            reason = "cache " + cstate
        to_classify.append({"id": r["id"], "title": r["title"], "reason": reason,
                            "input_extensions": sorted({ext_of(f) for f in r["input_files"] if ext_of(f)}),
                            "output_extensions": sorted({ext_of(f) for f in r["output_files"] if ext_of(f)})})
    cache_status = {"state": cstate, "detail": cdetail, "rubric_version": RUBRIC_VERSION,
                    "reused": len(cached), "sent_to_model": len(to_classify), "saved": "pending"}
    out = {"source": a.source, "today": a.today, "tz": a.tz or "UTC", "rows": rows,
           "self_runs": [{"id": r["id"], "title": r["title"], "created_date": r["created_date"],
                          "reason": r["self_run"]} for r in self_rows],
           "included_unconfirmed": sum(1 for r in rows if r.get("included_unconfirmed")),
           "invalid_dates": invalid_dates,
           "self_exclusion_confirmed": bool(self_ids),
           "recurring_groups": sorted(rec_groups.values(), key=lambda g: (-g["runs"], g["name"])),
           "triggers": triggers, "to_classify": to_classify, "cached_judgments": cached,
           "cache_status": cache_status,
           "discovery": ({k: discovery.get(k) for k in ("completeness", "counts_verified", "fingerprint",
                                                        "pages_read", "task_folders", "confirmed_empty_output",
                                                        "no_output_folder", "files_listed")}
                         if discovery else None),
           "cache_prior": ({"entries": entries, "last_run": cache.get("last_run")} if cache else None)}
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(json.dumps({"ok": True, "out": a.out, "rows": len(rows),
                      "invalid_dates_blanked": len(invalid_dates),
                      "self_exclusion_confirmed": bool(self_ids),
                      "self_runs_excluded": len(self_rows),
                      "recurring_confirmed": sum(r["recurring_confirmed"] for r in rows),
                      "recurring_unconfirmed": sum(r["recurring_flag"] and not r["recurring_confirmed"] for r in rows),
                      "to_classify": len(to_classify),
                      "reused_from_cache": len(cached),
                      "cache": f"{cstate}: {cdetail}",
                      "categories_allowed": CATEGORIES}, indent=2))


# ---------------------------------------------------------------- build
def decide(r, c):
    """Return (category, confidence, basis) or (None, None, reason) when excluded."""
    tc = c.get("title_category")
    explicit = bool(c.get("title_explicit"))
    has_outcome = bool(r["output_files"]) or bool(r["outcome_summary"])
    if r["state"].lower() in FAILED_STATES and not has_outcome:
        return None, None, f"{r['state']} with no outcome"
    if not has_outcome and tc is None:
        return None, None, "no output and no meaningful title"
    oc_all, ic_all = r["output_ext_category"], r["input_ext_category"]
    ec_all = oc_all or ic_all
    oc, ic = (oc_all[0] if oc_all else None), (ic_all[0] if ic_all else None)
    ec = oc or ic
    if tc and ec:
        if tc in ec_all:
            return tc, "High", "title and files agree"
        if explicit:
            return tc, "Medium", "title verb is explicit; files suggest " + ec
        return ec, "Medium", ("output" if oc else "input") + " files outweigh a non-explicit title"
    if tc:
        return tc, ("Medium" if explicit else "Low"), "title only (no file signal)"
    if ec:
        return ec, ("Medium" if oc else "Low"), ("output" if oc else "input") + " files only (vague title)"
    return "General assistance/Other", "Low", "vague title, outcome without file signal"


def repeatability_line(cst):
    st, saved = cst.get("state"), str(cst.get("saved", ""))
    if st in ("loaded", "new") and not saved.startswith("not saved"):
        tail = "" if saved == "saved" else " (once the cache upload is verified)"
        return (f"Repeatable{tail}: {cst.get('reused', 0)} title judgment(s) reused, "
                f"{cst.get('sent_to_model', 0)} new or changed judged this run ({cst.get('rubric_version')}).")
    return ("Not guaranteed repeatable: the classification cache is " + (st or "unavailable") +
            (f" ({cst.get('detail')})" if cst.get("detail") else "") +
            (f"; {saved}" if saved.startswith("not saved") else "") +
            ", so every title was judged fresh and a later run may classify some tasks differently.")


def compare_runs(prev, cur, totals_now):
    """Per-task comparison against the previous run, keyed by OneDrive folder id."""
    out = {"previous_run_date": None, "added": [], "removed": [], "changed": [], "unchanged": 0,
           "counts": {}, "delta": {}}
    if not prev or not isinstance(prev.get("tasks"), dict):
        out["counts"] = {"added": 0, "removed": 0, "changed": 0, "unchanged": 0}
        out["note"] = "no previous run recorded"
        return out
    out["previous_run_date"] = prev.get("run_date")
    ptasks = prev["tasks"]
    for tid in sorted(set(ptasks) | set(cur)):
        p, c = ptasks.get(tid), cur.get(tid)
        if p is None:
            out["added"].append({"id": tid, "title": c["title"], "status": c["status"], "category": c["category"],
                                 "mid_minutes": c["mid"], "why": "new task folder"})
            continue
        if c is None:
            out["removed"].append({"id": tid, "title": p["title"], "was": p["status"], "category": p["category"],
                                   "mid_minutes": p["mid"],
                                   "why": "task folder no longer listed (deleted, renamed or moved)"})
            continue
        same = all(p.get(k) == c.get(k) for k in ("status", "category", "confidence", "low", "mid", "high"))
        if same:
            out["unchanged"] += 1
            continue
        why = []
        if p.get("title_fp") != c.get("title_fp"):
            why.append("title changed")
        if p.get("judgment") != c.get("judgment"):
            why.append("title judgment changed")
        if p.get("output_evidence") != c.get("output_evidence") or p.get("input_evidence") != c.get("input_evidence"):
            why.append("file evidence changed")
        if p.get("automation_basis") != c.get("automation_basis"):
            why.append("automation evidence changed")
        if not why:
            why.append("status changed")
        out["changed"].append({"id": tid, "title": c["title"],
                               "before": f"{p['status']} {p['category']} {p['confidence']} {p['mid']} min".strip(),
                               "after": f"{c['status']} {c['category']} {c['confidence']} {c['mid']} min".strip(),
                               "mid_minutes_delta": c["mid"] - p["mid"], "why": "; ".join(why)})
    pt = prev.get("totals") or {}
    out["delta"] = {"tasks": totals_now["tasks"] - int(pt.get("tasks", 0))}
    for b in ("low", "mid", "high"):
        dm = totals_now[f"{b}_minutes"] - int(pt.get(f"{b}_minutes", 0))
        out["delta"][f"{b}_minutes"] = dm
        out["delta"][f"{b}_dollars"] = round(dm / 60.0 * RATE_PER_HOUR, 2)
    out["counts"] = {"added": len(out["added"]), "removed": len(out["removed"]),
                     "changed": len(out["changed"]), "unchanged": out["unchanged"]}
    return out


def cmd_run_id(a):
    """One shared file stem per run: cowork_value_<slug>_<local yyyy-mm-dd>-<HHMMSS>.
    Fixed up front so the CSV, HTML and XLSX of a run always share it, and two runs never
    publish the same name (each run publishes into its own task folder)."""
    now = dt.datetime.now(dt.timezone.utc)
    if a.now:
        now = dt.datetime.fromisoformat(a.now.replace("Z", "+00:00"))
        if now.tzinfo is None:
            now = now.replace(tzinfo=dt.timezone.utc)
    if a.tz:
        from zoneinfo import ZoneInfo
        now = now.astimezone(ZoneInfo(a.tz))
    day, suffix = now.strftime("%Y-%m-%d"), now.strftime("%H%M%S")
    stem = f"cowork_value_{slugify(a.name)}_{day}-{suffix}"
    print(json.dumps({"run_date": day, "run_suffix": suffix, "file_stem": stem,
                      "csv": stem + ".csv", "html": stem + ".html", "xlsx": stem + ".xlsx"}))


def cmd_cache_status(a):
    with open(a.summary, encoding="utf-8") as f:
        s = json.load(f)
    cst = s.setdefault("cache_status", {})
    cst["saved"] = a.saved
    s["repeatability"] = repeatability_line(cst)
    with open(a.summary, "w", encoding="utf-8") as f:
        json.dump(s, f, indent=2, ensure_ascii=False)
    print(json.dumps({"cache_status": cst, "repeatability": s["repeatability"]}))


def cmd_build(a):
    p = load_json(a.prepared, "prepared tasks")
    cls = load_json(a.classifications, "classifications")
    if not isinstance(cls, dict):
        fail("classifications JSON must be an object keyed by task id")
    need = {t["id"] for t in p["to_classify"]}
    missing = sorted(need - set(cls))
    if missing:
        fail(f"classifications missing for {len(missing)} task id(s): {missing[:10]}")
    extra = sorted(set(cls) - need)  # judgments for ids not sent to the model are ignored
    bad = [k for k in need if cls[k].get("title_category") not in CATEGORIES + [None]
           or not isinstance(cls[k].get("title_explicit", False), bool)]
    if bad:
        fail(f"invalid title_category/title_explicit for id(s) {bad[:10]}; allowed categories: {CATEGORIES} or null")
    judgments = dict(p.get("cached_judgments", {}))
    judgments.update({k: {"title_category": cls[k].get("title_category"),
                          "title_explicit": bool(cls[k].get("title_explicit")),
                          "rationale": str(cls[k].get("rationale", "")).strip()} for k in need})

    user, slug = a.user.strip(), slugify(a.user)
    run_date = p["today"]
    stem = os.path.basename(a.csv_out)[:-4] if a.csv_out.lower().endswith(".csv") else ""
    m = re.match(r"^cowork_value_(.+)_(\d{4}-\d{2}-\d{2})-(\d{6})$", stem)
    if not m or m.group(1) != slug or m.group(2) != run_date:
        fail(f"--csv-out must be the run's file stem from `run-id` + .csv "
             f"(cowork_value_{slug}_{run_date}-<HHMMSS>.csv), got {os.path.basename(a.csv_out)!r}")
    items, log, excluded, per_task = [], [], [], {}
    per = {c: {"tasks": 0, "low": 0, "mid": 0, "high": 0} for c in CATEGORIES}
    for r in p["rows"]:
        cat = conf = ""
        lo = mi = hi = ""
        status = "automation (not scored)" if r["recurring_flag"] else "scored"
        if not r["recurring_flag"]:
            c = judgments[r["id"]]
            cat, conf, basis = decide(r, c)
            if cat is None:
                excluded.append({"task_title": r["title"], "reason": basis, "created_date": r["created_date"]})
                cat = conf = ""
                status = "excluded (" + basis + ")"
            else:
                b = BANDS[cat]
                lo, mi, hi = b["low"], b["mid"], b["high"]
                per[cat]["tasks"] += 1
                for k in ("low", "mid", "high"):
                    per[cat][k] += b[k]
                log.append({"task_title": r["title"], "category": cat, "confidence": conf,
                            "basis": basis, "rationale": str(c.get("rationale", "")).strip()})
        per_task[r["id"]] = {
            "title": r["title"], "title_fp": r.get("title_fp", ""), "status": status,
            "category": cat, "confidence": conf,
            "low": lo if lo != "" else 0, "mid": mi if mi != "" else 0, "high": hi if hi != "" else 0,
            "output_evidence": r["output_ext_category"], "input_evidence": r["input_ext_category"],
            "automation_basis": r["recurring_basis"],
            "judgment": ({k: judgments[r["id"]].get(k) for k in ("title_category", "title_explicit")}
                         if r["id"] in judgments else None)}
        items.append({
            "user": safe_text(user), "task_title": safe_text(r["title"]),
            "created_date": r["created_date"], "state": safe_text(r["state"]),
            "outcome_summary": safe_text(r["outcome_summary"]),
            "recurring_flag": "True" if r["recurring_flag"] else "False",
            "category": cat, "classification_confidence": conf,
            "low_minutes": lo, "mid_minutes": mi, "high_minutes": hi})

    def hrs(m):
        return round(m / 60.0, 2)

    def usd(m):
        return round(m / 60.0 * RATE_PER_HOUR, 2)

    cats = [{"category": c, "tasks": v["tasks"],
             "low_hours": hrs(v["low"]), "mid_hours": hrs(v["mid"]), "high_hours": hrs(v["high"]),
             "low_dollars": usd(v["low"]), "mid_dollars": usd(v["mid"]), "high_dollars": usd(v["high"])}
            for c, v in per.items()]
    tot = {k: sum(v[k] for v in per.values()) for k in ("tasks", "low", "mid", "high")}
    dates = sorted(r["created_date"] for r in p["rows"] if r["created_date"])
    date_range = f"{dates[0]} to {dates[-1]}" if dates else "unknown"
    rec_unconf = sum(1 for r in p["rows"] if r["recurring_flag"] and not r.get("recurring_confirmed"))
    for sr in p.get("self_runs", []):
        per_task[sr["id"]] = {"title": sr["title"], "title_fp": "", "status": "report run (never counted)",
                              "category": "", "confidence": "", "low": 0, "mid": 0, "high": 0,
                              "output_evidence": [], "input_evidence": [], "automation_basis": "",
                              "judgment": None}
    totals_now = {"tasks": tot["tasks"], "low_minutes": tot["low"], "mid_minutes": tot["mid"],
                  "high_minutes": tot["high"]}
    prior = p.get("cache_prior") or {}
    comparison = compare_runs(prior.get("last_run"), per_task, totals_now)

    cstat = dict(p.get("cache_status") or {"state": "not used", "detail": "", "saved": "not saved"})
    if a.cache_out and cstat.get("state") in ("loaded", "new"):
        entries = dict(prior.get("entries") or {})
        for tid, j in judgments.items():
            r = next(x for x in p["rows"] if x["id"] == tid)
            old = entries.get(tid)
            if (old and old.get("title_fp") == r["title_fp"] and old.get("rubric_version") == RUBRIC_VERSION):
                continue  # unchanged: keep the original record and its date
            entries[tid] = {"title": r["title"], "title_fp": r["title_fp"], "rubric_version": RUBRIC_VERSION,
                            "title_category": j["title_category"], "title_explicit": j["title_explicit"],
                            "rationale": j["rationale"], "judged_on": run_date}
        os.makedirs(os.path.dirname(os.path.abspath(a.cache_out)), exist_ok=True)
        with open(a.cache_out, "w", encoding="utf-8") as f:
            json.dump({"schema": CACHE_SCHEMA, "user_slug": slug, "rubric_version": RUBRIC_VERSION,
                       "entries": dict(sorted(entries.items())),
                       "last_run": {"run_date": run_date, "tasks": per_task, "totals": totals_now}},
                      f, indent=2, ensure_ascii=False)
            f.write("\n")
        cstat["saved"] = "pending upload"
        cstat["cache_file"] = a.cache_out
    else:
        cstat["saved"] = "not saved: " + (cstat.get("detail") or "cache not available")
    s = {"user": user, "user_slug": slug, "run_date": run_date, "tz": p.get("tz", "UTC"),
         "one_off_tasks": tot["tasks"],
         "low_hours": hrs(tot["low"]), "mid_hours": hrs(tot["mid"]), "high_hours": hrs(tot["high"]),
         "low_dollars": usd(tot["low"]), "mid_dollars": usd(tot["mid"]), "high_dollars": usd(tot["high"]),
         "coverage": {"rows": len(p["rows"]), "source": p["source"], "date_range": date_range},
         "categories": cats,
         "recurring_excluded": sum(1 for r in p["rows"] if r["recurring_flag"]),
         "recurring_unconfirmed": rec_unconf,
         "self_runs_excluded": len(p.get("self_runs", [])), "self_runs": p.get("self_runs", []),
         "included_unconfirmed": int(p.get("included_unconfirmed", 0)),
         "invalid_dates_blanked": len(p.get("invalid_dates", [])), "invalid_dates": p.get("invalid_dates", []),
         "self_exclusion_confirmed": bool(p.get("self_exclusion_confirmed")),
         "recurring_groups": p["recurring_groups"], "triggers": p.get("triggers", []),
         "no_outcome_excluded": len(excluded), "excluded": excluded,
         "classification_log": log, "rate_per_hour": RATE_PER_HOUR, "bands_source": BANDS_SOURCE,
         "file_stem": stem, "run_suffix": m.group(3),
         "cache_status": cstat, "repeatability": repeatability_line(cstat),
         "discovery": p.get("discovery"),
         "run_comparison": comparison, "per_task": per_task,
         "items": items}
    for path in (a.summary_out, a.csv_out):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(a.summary_out, "w", encoding="utf-8") as f:
        json.dump(s, f, indent=2, ensure_ascii=False)
    with open(a.csv_out, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(CSV_COLUMNS)
        for it in items:
            w.writerow(["" if it[k] is None else it[k] for k in CSV_COLUMNS])
    print(json.dumps({"ok": True, "user": user, "user_slug": slug, "run_date": run_date,
                      "one_off_tasks": s["one_off_tasks"],
                      "mid_hours": s["mid_hours"], "mid_dollars": s["mid_dollars"],
                      "low_hours": s["low_hours"], "low_dollars": s["low_dollars"],
                      "high_hours": s["high_hours"], "high_dollars": s["high_dollars"],
                      "recurring_excluded": s["recurring_excluded"], "recurring_unconfirmed": rec_unconf,
                      "self_runs_excluded": s["self_runs_excluded"],
                      "self_exclusion_confirmed": s["self_exclusion_confirmed"],
                      "invalid_dates_blanked": s["invalid_dates_blanked"],
                      "no_outcome_excluded": s["no_outcome_excluded"],
                      "unused_classification_ids": extra[:10],
                      "cache_status": cstat, "repeatability": s["repeatability"],
                      "discovery": s["discovery"],
                      "run_comparison": {k: comparison[k] for k in ("previous_run_date", "counts", "delta")},
                      "file_stem": stem, "summary": a.summary_out, "csv": a.csv_out}, indent=2))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("slug")
    s.add_argument("--name", required=True)
    pr = sub.add_parser("prepare")
    pr.add_argument("--tasks", required=True)
    pr.add_argument("--source", required=True)
    pr.add_argument("--today", required=True)
    pr.add_argument("--tz")
    pr.add_argument("--triggers")
    pr.add_argument("--exclude-ids", nargs="*", default=[],
                    help="task folder ids to leave out entirely -- this run's own folder, ONLY when its id is known")
    pr.add_argument("--discovery", help="discovery_report.json from discover_tasks.py (required for OneDrive input)")
    pr.add_argument("--cache-in", help="downloaded classification cache (omit on the first run)")
    pr.add_argument("--cache-skip", help="reason the cache could not be loaded; nothing is reused or saved")
    pr.add_argument("--include-unconfirmed", action="store_true",
                    help="score repeated/untitled tasks that match no trigger (only when the user asks)")
    pr.add_argument("--out", default="working/value_tasks_prepared.json")
    b = sub.add_parser("build")
    b.add_argument("--prepared", default="working/value_tasks_prepared.json")
    b.add_argument("--classifications", required=True)
    b.add_argument("--user", required=True)
    b.add_argument("--summary-out", default="working/cowork_value_summary.json")
    b.add_argument("--csv-out", required=True)
    b.add_argument("--cache-out", help="local path for the updated classification cache to upload")
    ri = sub.add_parser("run-id")
    ri.add_argument("--name", required=True, help="display name (slugged with the shared rule)")
    ri.add_argument("--tz", help="IANA zone; the date and time are local to the user")
    ri.add_argument("--now", help="ISO time to use instead of the clock (tests only)")
    cs = sub.add_parser("cache-status")
    cs.add_argument("--summary", default="working/cowork_value_summary.json")
    cs.add_argument("--saved", required=True, help='"saved" or "not saved: <reason>"')
    a = ap.parse_args()
    if a.cmd == "slug":
        print(json.dumps({"slug": slugify(a.name)}))
    elif a.cmd == "prepare":
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", a.today):
            fail("--today must be yyyy-mm-dd")
        cmd_prepare(a)
    elif a.cmd == "run-id":
        cmd_run_id(a)
    elif a.cmd == "cache-status":
        cmd_cache_status(a)
    else:
        cmd_build(a)


if __name__ == "__main__":
    main()
