#!/usr/bin/env python3
"""Deterministic OneDrive discovery for the Cowork Value ESTIMATE. Standard library only.

Cowork's OneDrive tools are called by the model, not by Python. The model's only job
is to make the fixed listing calls in SKILL.md Step 1 and save every page it gets
back, unedited, as one JSON file per page in a pages folder. This script does the
rest, the same way every time:

  * follows each listing's page chain and refuses a chain with a missing page or a
    final page that still has a continuation;
  * de-duplicates rows by item id (a row repeated across pages must be identical);
  * joins task folder -> input/ and output/ subfolder -> files strictly by parent
    folder id (never by name or path text);
  * checks every folder it relies on against the folder's own childCount, so an
    empty folder is CONFIRMED empty (childCount 0) and a short read is INCOMPLETE;
  * sorts the result (created date, then folder id) and fingerprints it, so the
    same OneDrive contents always give byte-identical tasks.json.

Usage
  python discover_tasks.py --pages working/discovery --root-id <Tasks folder item id>
      --root-child-count <Tasks folder childCount> --out working/tasks.json
      --report working/discovery_report.json [--accept-pagination-only]

Page file (one per page, any file name ending .json):
  {"listing": "root" | "subfolders" | "files",
   "parents": ["<folder id>", ...],   # ids this listing was asked for; omit for "root"
   "page": 0, 1, 2, ...,              # order within this listing
   "next": "<continuation token/link>" | null,   # exactly as the tool returned it
   "rows": [ <rows exactly as the tool returned them> ]}

Row fields are read under any of these spellings:
  id; name; parent id: parentId | parent_id | parentReference.id;
  childCount: childCount | child_count | folder.childCount (folders only);
  folder marker: isFolder | is_folder | a "folder" object; createdDateTime | created.

Exit codes: 0 complete; 2 malformed pages; 3 INCOMPLETE read -- nothing may be scored.
--accept-pagination-only: when the tool exposes no childCount, accept complete page
chains as the only completeness evidence; the report says so (never silent).
"""
import argparse
import glob
import hashlib
import json
import os
import sys


def fail(code, msg, **extra):
    print(json.dumps({"ok": False, "complete": False, "error": msg, **extra}, indent=2))
    sys.exit(code)


def pick(row, *paths):
    for p in paths:
        cur = row
        for part in p.split("."):
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            else:
                cur = None
                break
        if cur not in (None, ""):
            return cur
    return None


def norm_row(r):
    rid = pick(r, "id", "item_id")
    if rid in (None, ""):
        return None
    folder_obj = r.get("folder") if isinstance(r.get("folder"), dict) else None
    is_folder = bool(pick(r, "isFolder", "is_folder")) or folder_obj is not None
    cc = pick(r, "childCount", "child_count", "folder.childCount", "folder_child_count")
    return {"id": str(rid), "name": str(pick(r, "name") or ""),
            "parent": (str(pick(r, "parentId", "parent_id", "parentReference.id"))
                       if pick(r, "parentId", "parent_id", "parentReference.id") is not None else None),
            "is_folder": is_folder,
            "child_count": int(cc) if isinstance(cc, (int, float, str)) and str(cc).strip().isdigit() else None,
            "created": str(pick(r, "createdDateTime", "created", "created_date_time") or "")}


def load_pages(folder):
    files = sorted(glob.glob(os.path.join(folder, "*.json")))
    if not files:
        fail(3, f"no page files in {folder}: the listing was not saved, so completeness cannot be shown")
    chains = {}
    for path in files:
        try:
            with open(path, encoding="utf-8-sig") as f:
                pg = json.load(f)
        except Exception as e:
            fail(2, f"unreadable page file {os.path.basename(path)}: {e}")
        kind = pg.get("listing")
        if kind not in ("root", "subfolders", "files"):
            fail(2, f"{os.path.basename(path)}: listing must be root, subfolders or files")
        parents = tuple(sorted(str(x) for x in (pg.get("parents") or [])))
        if kind != "root" and not parents:
            fail(2, f"{os.path.basename(path)}: a {kind} listing must name the parent folder ids it asked for")
        if not isinstance(pg.get("page"), int) or not isinstance(pg.get("rows"), list):
            fail(2, f"{os.path.basename(path)}: needs an integer 'page' and a 'rows' list")
        chains.setdefault((kind, parents), {})
        if pg["page"] in chains[(kind, parents)]:
            fail(2, f"{os.path.basename(path)}: page {pg['page']} of the same listing saved twice")
        chains[(kind, parents)][pg["page"]] = pg
    return chains


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pages", required=True)
    ap.add_argument("--root-id", required=True)
    ap.add_argument("--root-child-count", type=int)
    ap.add_argument("--out", required=True)
    ap.add_argument("--report", required=True)
    ap.add_argument("--accept-pagination-only", action="store_true")
    a = ap.parse_args()

    chains = load_pages(a.pages)
    problems, rows = [], {}
    covered = {"root": set(), "subfolders": set(), "files": set()}
    for (kind, parents), pages in sorted(chains.items()):
        idx = sorted(pages)
        label = f"{kind} listing for {list(parents) or ['Tasks']}"
        if idx != list(range(len(idx))):
            problems.append(f"{label}: missing page(s) -- have {idx}")
        last = pages[idx[-1]]
        if last.get("next"):
            problems.append(f"{label}: last saved page {idx[-1]} still has a continuation (not all pages followed)")
        for i in idx[:-1]:
            if not pages[i].get("next"):
                problems.append(f"{label}: page {i} has no continuation but later pages exist")
        for i in idx:
            for raw in pages[i]["rows"]:
                r = norm_row(raw) if isinstance(raw, dict) else None
                if r is None:
                    fail(2, f"{label} page {i}: a row has no id")
                if kind == "root" and r["parent"] is None:
                    r["parent"] = a.root_id
                if r["parent"] is None:
                    fail(2, f"{label} page {i}: row {r['id']} has no parent folder id; "
                            "select parentReference / parent id in the listing")
                if kind != "root" and r["parent"] not in parents:
                    fail(2, f"{label} page {i}: row {r['id']} belongs to {r['parent']}, not to the requested parents")
                if r["id"] in rows and rows[r["id"]] != r:
                    fail(2, f"item {r['id']} appears twice with different values (listing changed mid-read?); rerun")
                rows[r["id"]] = r
        covered[kind].update(parents if kind != "root" else (a.root_id,))
    if problems:
        fail(3, "INCOMPLETE read: " + " | ".join(problems), problems=problems)

    def children(pid):
        return sorted((r for r in rows.values() if r["parent"] == pid), key=lambda r: r["id"])

    counts_ok = True
    unverified = []

    def check(folder_id, label, expected, listed_kind):
        nonlocal counts_ok
        if folder_id not in covered[listed_kind]:
            if expected == 0:
                return "confirmed empty"
            problems.append(f"{label}: not listed" + (f" (childCount {expected})" if expected else ""))
            return "incomplete"
        n = len(children(folder_id))
        if expected is None:
            counts_ok = False
            unverified.append(label)
            return "listed (count not verifiable)"
        if n != expected:
            problems.append(f"{label}: listed {n} item(s) but childCount is {expected}")
            return "incomplete"
        return "confirmed empty" if n == 0 else "complete"

    if a.root_id not in covered["root"]:
        fail(3, "INCOMPLETE read: the Tasks folder listing (listing: root) was not saved")
    root_status = check(a.root_id, "Tasks folder", a.root_child_count, "root")
    task_folders = [r for r in children(a.root_id) if r["is_folder"]]

    tasks, folder_report = [], []
    for tf in task_folders:
        subs = {r["name"].strip().lower(): r for r in children(tf["id"]) if r["is_folder"]}
        st = check(tf["id"], f"task folder '{tf['name']}'", tf["child_count"], "subfolders")
        entry = {"id": tf["id"], "name": tf["name"], "folder": st}
        files = {}
        for sub in ("input", "output"):
            sf = subs.get(sub)
            if sf is None:
                entry[sub] = "absent" if st in ("complete", "confirmed empty") else "unknown"
                files[sub] = []
                continue
            entry[sub] = check(sf["id"], f"'{tf['name']}/{sub}'", sf["child_count"], "files")
            files[sub] = sorted(r["name"] for r in children(sf["id"]) if not r["is_folder"])
        folder_report.append(entry)
        tasks.append({"id": tf["id"], "name": tf["name"], "created": tf["created"],
                      "input_files": files["input"], "output_files": files["output"]})

    if problems:
        fail(3, "INCOMPLETE read: " + " | ".join(problems[:10]), problems=problems, folders=folder_report)
    if not counts_ok and not a.accept_pagination_only:
        fail(3, "INCOMPLETE read: the listing exposes no childCount, so empty and short folders cannot be "
                "told apart. Re-list with the folder childCount column, or rerun with --accept-pagination-only "
                "to rely on complete page chains alone (disclosed in the report).",
             unverified=unverified[:20])

    tasks.sort(key=lambda t: (t["created"], t["id"]))
    blob = json.dumps(tasks, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    fingerprint = hashlib.sha256(blob).hexdigest()[:16]
    completeness = ("verified: every page chain complete and every folder count matches childCount"
                    if counts_ok else
                    "page chains complete; folder counts NOT verifiable (no childCount) -- accepted by flag")
    report = {"ok": True, "complete": True, "completeness": completeness, "counts_verified": counts_ok,
              "root": root_status, "task_folders": len(tasks),
              "confirmed_empty_output": sum(1 for f in folder_report if f.get("output") == "confirmed empty"),
              "no_output_folder": sum(1 for f in folder_report if f.get("output") == "absent"),
              "files_listed": sum(len(t["input_files"]) + len(t["output_files"]) for t in tasks),
              "pages_read": sum(len(p) for p in chains.values()), "fingerprint": fingerprint,
              "unverified_folders": unverified, "folders": folder_report}
    for path in (a.out, a.report):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(tasks, f, indent=2, ensure_ascii=False, sort_keys=True)
        f.write("\n")
    with open(a.report, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print(json.dumps({k: report[k] for k in ("ok", "complete", "completeness", "task_folders",
                                             "confirmed_empty_output", "no_output_folder", "files_listed",
                                             "pages_read", "fingerprint")}, indent=2))


if __name__ == "__main__":
    main()
