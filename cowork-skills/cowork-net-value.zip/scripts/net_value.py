#!/usr/bin/env python3
"""Net this month's Cowork savings ESTIMATE against this billing period's credit cost.

All arithmetic happens here, never in chat. Standard library + pandas.

  slug   --name "<display name>"
         Prints {"slug": ...}. Identical rule to cowork-value-report's value_constants.slugify.

  pick   --user <slug> --items <listing.json> [--today <yyyy-mm-dd>] [--out working/net_value_pick.json]
         Selects ONE exact OneDrive item for THIS user from the listed output/ files
         (each: name, id, driveId, size, lastModifiedDateTime, optional quickXorHash,
         parentPath). Order: newest date in the name, then latest lastModifiedDateTime
         (same-named reports in different task folders), then the run suffix, then item id.
         Writes the selection file compute reads, lists older same-named copies, and
         with --today reports current_month / age_days / stale_warning.

  check-credits --credits <n> [--today <yyyy-mm-dd>] [--credits-confirmed]
         [--min-month-credits <n, default 1000>]
         Sanity-checks the month-to-date credit count. With --today the threshold is
         prorated by day of month (floor 100), so legitimate early-month totals pass.
         Under the threshold -> {"needs_confirmation": true, "ask": ...}, exit 3,
         unless --credits-confirmed (the user re-confirmed the same number).

  compute --csv <local download> [--selected working/net_value_pick.json] --default-drive-id <id>
          --user <slug> --today <yyyy-mm-dd, user's local date> [--tz <IANA zone>]
          --credits <n> [--credits-confirmed] [--min-month-credits <n>]
          [--rate <number, default 0.01>] [--max-age-days <n, default 3>] --out-dir working
         Verifies the download is the selected item (name, byte size -- plus QuickXorHash
         content match when the listing supplied one -- owner slug, same
         OneDrive as GetDefaultDrive, every row's user = the signed-in user and never
         blank, timestamp consistent) and that every scored row has its category's
         exact band minutes and a real created date no later than the report snapshot
         -- otherwise exit 2.
         Refuses (exit 4) a CSV produced before the current calendar month; flags one
         older than --max-age-days (stale_warning). Filters rows to created_date in the
         current month (local), recurring_flag not set, mid_minutes populated. Sums
         Low/Mid/High minutes -> hours (/60) -> dollars ($72/hr), nets each band
         against credits x rate, writes working/cowork_net_value_<user>_<yyyy-mm>.csv (one row,
         for automation) and the matching .xlsx (Results + Legend tabs). The CSV header,
         both tabs and the JSON "legend" all come from COLUMN_DEFS.

Exit codes: 0 ok; 2 bad input; 3 credits need the user's one-time confirmation;
            4 the value-report CSV is from an earlier month (rerun the value report).
"""
import argparse
import base64
import calendar
import datetime as dt
import json
import math
import os
import re
import sys
import unicodedata

RATE_PER_HOUR = 72.0            # same loaded rate as cowork-value-report
DEFAULT_RATE_PER_CREDIT = 0.01  # Copilot Studio pay-as-you-go list price (commercial)
MIN_MONTH_CREDITS = 1000        # full-month threshold; prorated by day when --today is given
MIN_THRESHOLD_FLOOR = 100
MAX_AGE_DAYS = 3
CONFIRM_ASK = ("That number looks like it might be the single-task figure rather than the "
               "month-to-date total shown next to 'credits used so far this month' -- can you "
               "confirm, or give me the larger number?")
# cowork_value_<slug>_<yyyy-mm-dd>[-<HHMMSS run suffix> | legacy -<HHMM>].csv
NAME_RE = re.compile(r"^cowork_value_(.+?)_(\d{4}-\d{2}-\d{2})(?:-(\d{6}|\d{4}))?\.csv$", re.IGNORECASE)
REQUIRED = ["user", "created_date", "recurring_flag", "category", "low_minutes", "mid_minutes", "high_minutes"]

# Effort bands (minutes) -- keep identical to cowork-value-report/scripts/value_constants.py.
# Every scored row must carry exactly its category's Low/Mid/High.
BANDS = {
    "Analysis & Research": (30, 67, 92),
    "Document & content creation": (12, 24, 42),
    "Email workflows": (3, 7, 12),
    "Meeting workflows": (12, 31, 45),
    "Communication workflows": (2, 4, 6),
    "Specialized workflows": (10, 25, 40),
    "Write or debug code": (30, 56, 96),
    "General assistance/Other": (2, 5, 8),
}
# Single source for the exported columns AND their legend. The CSV header, the XLSX
# "Results" and "Legend" tabs and the chat legend (compute's JSON "legend") are all
# generated from this list, so they cannot drift apart. One entry per exported column.
COLUMN_DEFS = [
    ("user", "Whose data this is -- always the signed-in user, never anyone else"),
    ("month", "The calendar month analyzed, matching the billing period the credits cover"),
    ("source_csv_date", "Date of the cowork-value-report CSV used; tasks created after it are not counted"),
    ("tasks_this_month", "Count of scored one-off Cowork tasks created that month (recurring/automation runs excluded)"),
    ("low_hours", "Savings ESTIMATE, Low (defensible floor) band -- hours those tasks would have taken manually"),
    ("low_dollars", "Savings ESTIMATE, Low band in dollars -- low_hours x $72/hr; the conservative number"),
    ("mid_hours", "Savings ESTIMATE, Mid (typical) band -- hours those tasks would have taken manually"),
    ("mid_dollars", "Savings ESTIMATE, Mid band in dollars -- mid_hours x $72/hr; the headline number"),
    ("high_hours", "Savings ESTIMATE, High band -- hours, shown for completeness, not the headline"),
    ("high_dollars", "Savings ESTIMATE, High band in dollars -- high_hours x $72/hr"),
    ("credits_entered", "The credit count you supplied -- ALL your Cowork credit usage for the month (every task, "
                        "including recurring/failed/excluded ones), not just the scored tasks in tasks_this_month"),
    ("rate_per_credit", "The $/credit conversion used -- the public pay-as-you-go list price or your override, not a "
                        "confirmed tenant-negotiated rate"),
    ("credit_cost", "APPROXIMATE credit cost -- credits_entered x rate_per_credit"),
    ("net_low", "NET ESTIMATE at the Low band -- low_dollars minus credit_cost"),
    ("net_mid", "NET ESTIMATE at the Mid band -- mid_dollars minus credit_cost; the bottom-line headline"),
    ("net_high", "NET ESTIMATE at the High band -- high_dollars minus credit_cost"),
]
OUT_COLUMNS = [c for c, _ in COLUMN_DEFS]
LEGEND = COLUMN_DEFS
if len(set(OUT_COLUMNS)) != len(OUT_COLUMNS) or any(not m.strip() for _, m in COLUMN_DEFS):
    raise SystemExit("COLUMN_DEFS must name each exported column once, each with a meaning")


def quickxorhash_b64(data):
    """OneDrive QuickXorHash (base64), as Graph reports in file.hashes.quickXorHash.
    160-bit circular-shift XOR (shift 11), file length XORed into the last 8 bytes.
    Verified against the 34 published rclone test vectors (0-40 bytes)."""
    width, mask = 160, (1 << 160) - 1
    h, shift = 0, 0
    for b in data:
        v = b << shift
        h ^= (v | (v >> width)) & mask
        shift = (shift + 11) % width
    out = bytearray(h.to_bytes(20, "little"))
    for i, lb in enumerate(len(data).to_bytes(8, "little")):
        out[12 + i] ^= lb
    return base64.b64encode(bytes(out)).decode("ascii")


def fail(msg, code=2, **extra):
    print(json.dumps({"ok": False, "error": msg, **extra}))
    sys.exit(code)


def slugify(name):
    """Display name -> file-name slug. 'Jose O'Brien' (accents folded) -> 'jose-obrien'. Keep identical to value_constants.py."""
    s = unicodedata.normalize("NFKD", str(name or "")).encode("ascii", "ignore").decode("ascii")
    s = re.sub(r"['\u2019`]", "", s.lower())
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s or "user"


def as_bool(v):
    # Same truthiness rule as cowork-value-report
    return str(v).strip().lower() in ("true", "1", "yes", "y", "recurring")


def parse_number(text, label):
    s = str(text).strip().replace("$", "").replace(",", "")
    try:
        v = float(s)
    except ValueError:
        fail(f"{label} is not a plain number: {text!r}")
    if not math.isfinite(v):
        fail(f"{label} is not a finite number: {text!r}")
    return v


def parse_date(text, label):
    try:
        return dt.date.fromisoformat(str(text).strip())
    except ValueError:
        fail(f"{label} must be yyyy-mm-dd: {text!r}")


def threshold_for(base, today):
    if today is None:
        return float(base)
    days = calendar.monthrange(today.year, today.month)[1]
    return float(max(MIN_THRESHOLD_FLOOR, round(base * today.day / days)))


def credits_check(credits, confirmed, threshold):
    """None when the credit count can be used, else the confirmation payload (ask at most once)."""
    if credits < threshold and not confirmed:
        return {"ok": False, "needs_confirmation": True, "credits": credits,
                "threshold": threshold, "ask": CONFIRM_ASK}
    return None


def read_credits(args):
    if args.credits is None or str(args.credits).strip() == "":
        fail("credits not provided")
    credits = parse_number(args.credits, "credits")
    if credits < 0:
        fail("credits must not be negative")
    return credits


def cmd_slug(args):
    print(json.dumps({"slug": slugify(args.name)}))


def cmd_check_credits(args):
    credits = read_credits(args)
    today = parse_date(args.today, "--today") if args.today else None
    thr = threshold_for(args.min_month_credits, today)
    pending = credits_check(credits, args.credits_confirmed, thr)
    if pending:
        print(json.dumps(pending))
        sys.exit(3)
    print(json.dumps({"ok": True, "credits": credits, "confirmed": bool(args.credits_confirmed),
                      "threshold": thr}))


def parse_utc(text):
    v = str(text or "").strip()
    try:
        d = dt.datetime.fromisoformat(v.replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=dt.timezone.utc)


def cmd_pick(args):
    """Select ONE exact OneDrive item: newest date in the name, then latest lastModifiedDateTime
    (same-named reports in different task folders), then the run suffix (-HHMMSS, legacy -HHMM), then item id."""
    try:
        with open(args.items, encoding="utf-8-sig") as f:
            items = json.load(f)
    except Exception as e:
        fail(f"could not read --items listing: {e}")
    if not isinstance(items, list):
        fail("--items must be a JSON list of listed files")
    want = args.user.strip().lower()
    cands, others, skipped = [], 0, []
    for it in items:
        name = os.path.basename(str(it.get("name", "")).strip())
        m = NAME_RE.match(name)
        if not m:
            continue
        if m.group(1).lower() != want:
            others += 1
            continue
        mod = parse_utc(it.get("lastModifiedDateTime"))
        missing = [k for k in ("id", "driveId", "size") if it.get(k) in (None, "")]
        if mod is None or missing:
            skipped.append({"name": name, "id": it.get("id"),
                            "why": "missing " + ", ".join(missing + ([] if mod else ["lastModifiedDateTime"]))})
            continue
        cands.append({"key": (m.group(2), mod, (m.group(3) or "").ljust(6, "0"), str(it["id"])),
                      "name": name, "date": m.group(2), "run_suffix": m.group(3),
                      "id": str(it["id"]), "driveId": str(it["driveId"]), "size": int(it["size"]),
                      "lastModifiedDateTime": mod.isoformat(),
                      "quickXorHash": it.get("quickXorHash") or None,
                      "parent": it.get("parentPath") or it.get("parentId") or None})
    if not cands:
        print(json.dumps({"found": False, "ignored_other_users": others, "skipped_incomplete": skipped}))
        return
    cands.sort(key=lambda c: c["key"])
    best = cands[-1]
    same_name = [{"id": c["id"], "lastModifiedDateTime": c["lastModifiedDateTime"], "parent": c["parent"]}
                 for c in cands[:-1] if c["name"] == best["name"]]
    sel = {k: best[k] for k in ("name", "date", "run_suffix", "id", "driveId", "size", "lastModifiedDateTime",
                                "quickXorHash", "parent")}
    sel.update({"user": want, "selected_on": args.today})
    out = {"found": True, **sel, "ignored_other_users": others, "skipped_incomplete": skipped,
           "same_name_older_copies": same_name, "candidates": len(cands)}
    if args.today:
        today, d = parse_date(args.today, "--today"), dt.date.fromisoformat(best["date"])
        age = (today - d).days
        out.update({"current_month": (d.year, d.month) == (today.year, today.month), "age_days": age,
                    "stale_warning": (f"The value report CSV is {age} days old ({d}); tasks created after "
                                      "it are not counted.") if age > args.max_age_days else None})
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(sel, f, indent=2)
    out["selection_file"] = args.out
    print(json.dumps(out, indent=2))


def write_xlsx(path, row, rate_defaulted, identity_check):
    """Results + Legend workbook from COLUMN_DEFS. Returns None, or a reason it was skipped."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except ImportError:
        return "openpyxl is not available in this environment"
    head_fill, head_font = PatternFill("solid", fgColor="DEECF9"), Font(bold=True, color="005A9E")
    money = {"low_dollars", "mid_dollars", "high_dollars", "credit_cost", "net_low", "net_mid", "net_high"}
    hours = {"low_hours", "mid_hours", "high_hours"}

    def text(v):  # never let a value become a formula
        if isinstance(v, str) and v.startswith(("=", "+", "-", "@")):
            return "'" + v
        return v

    wb = Workbook()
    ws = wb.active
    ws.title = "Results"
    ws.cell(1, 1, f"Cowork NET value ESTIMATE -- {row['user']}, {row['month']}").font = Font(bold=True, size=14,
                                                                                              color="005A9E")
    ws.cell(2, 1, "Every figure is an ESTIMATE (savings) or APPROXIMATE (credit cost) -- never billed, measured "
                  "or realized savings." + (" Default $0.01/credit rate used." if rate_defaulted else ""))
    ws.cell(3, 1, f"File check: {identity_check}")
    for j, col in enumerate(OUT_COLUMNS, 1):
        h = ws.cell(5, j, col)
        h.font, h.fill = head_font, head_fill
        h.alignment = Alignment(wrap_text=True, vertical="top")
        c = ws.cell(6, j, text(row[col]))
        if col in money:
            c.number_format = '$#,##0.00;[Red]-$#,##0.00'
        elif col in hours:
            c.number_format = "#,##0.00"
        elif col == "rate_per_credit":
            c.number_format = "$0.0000"
        elif col == "credits_entered":
            c.number_format = "#,##0"
        ws.column_dimensions[get_column_letter(j)].width = max(12, len(col) + 2)
    ws.freeze_panes = "A6"
    lg = wb.create_sheet("Legend")
    for j, lab in enumerate(("Column", "Meaning"), 1):
        h = lg.cell(1, j, lab)
        h.font, h.fill = head_font, head_fill
    for i, (col, meaning) in enumerate(COLUMN_DEFS, 2):
        lg.cell(i, 1, col)
        lg.cell(i, 2, meaning).alignment = Alignment(wrap_text=True, vertical="top")
    lg.column_dimensions["A"].width, lg.column_dimensions["B"].width = 20, 100
    lg.freeze_panes = "A2"
    wb.save(path)
    return None


def cmd_compute(args):
    import pandas as pd

    credits = read_credits(args)
    rate_given = args.rate is not None and str(args.rate).strip() != ""
    rate = parse_number(args.rate, "rate") if rate_given else DEFAULT_RATE_PER_CREDIT
    if rate < 0:
        fail("rate must not be negative")
    today = parse_date(args.today, "--today")
    month = today.strftime("%Y-%m")

    # Bind the calculation to the exact OneDrive item `pick` selected (selection file written by pick).
    try:
        with open(args.selected, encoding="utf-8") as f:
            sel = json.load(f)
        for k in ("name", "id", "driveId", "size", "lastModifiedDateTime"):
            if sel.get(k) in (None, ""):
                raise ValueError(f"missing {k}")
    except Exception as e:
        fail(f"could not read the pick selection file {args.selected!r}: {e}")
    args.csv_name, args.item_id, args.drive_id = sel["name"], sel["id"], sel["driveId"]
    args.item_size, args.item_modified = int(sel["size"]), sel["lastModifiedDateTime"]
    args.item_quickxorhash = sel.get("quickXorHash")
    m = NAME_RE.match(os.path.basename(args.csv_name.strip()))
    if not m:
        fail(f"selected item name is not a cowork_value CSV name: {args.csv_name!r}")
    if m.group(1).lower() != args.user.lower():
        fail(f"selected item belongs to '{m.group(1)}', not the signed-in user '{args.user}'")
    local_base = os.path.basename(args.csv)
    if NAME_RE.match(local_base) and local_base.lower() != os.path.basename(args.csv_name).lower():
        fail(f"local file {local_base!r} is not the selected item {args.csv_name!r}")
    if args.drive_id.strip().lower() != args.default_drive_id.strip().lower():
        fail("the selected CSV is not on the signed-in user's own OneDrive (drive id mismatch)")
    csv_date = dt.date.fromisoformat(m.group(2))
    try:
        local_size = os.path.getsize(args.csv)
    except OSError as e:
        fail(f"could not read the downloaded file: {e}")
    if local_size != args.item_size:
        fail(f"downloaded file is {local_size} bytes but the selected OneDrive item is {args.item_size} bytes; "
             "it is not the selected file")
    identity_check = "size only (same-size different file not detectable)"
    if args.item_quickxorhash:
        with open(args.csv, "rb") as fh:
            local_hash = quickxorhash_b64(fh.read())
        if local_hash != args.item_quickxorhash.strip():
            fail("downloaded file's QuickXorHash does not match the selected OneDrive item; it is not the selected file")
        identity_check = "size + QuickXorHash (content verified)"
    try:
        mod = dt.datetime.fromisoformat(args.item_modified.strip().replace("Z", "+00:00"))
    except ValueError:
        fail(f"selected item lastModifiedDateTime is not an ISO date-time: {args.item_modified!r}")
    if mod.tzinfo is None:
        mod = mod.replace(tzinfo=dt.timezone.utc)
    if args.tz:
        from zoneinfo import ZoneInfo
        mod = mod.astimezone(ZoneInfo(args.tz))
    mod_date = mod.date()
    if mod_date < csv_date:
        fail(f"item last modified {mod_date} is before the date in its name ({csv_date}); file is inconsistent")

    if csv_date > today:
        fail(f"CSV date {csv_date} is after today {today}; check --today / time zone")
    if (csv_date.year, csv_date.month) != (today.year, today.month):
        fail(f"The newest cowork_value CSV is from {csv_date}, before this billing month ({month}).",
             code=4, stale=True, csv_date=str(csv_date), month=month)
    age = (today - csv_date).days
    stale_warning = (f"The value report CSV is {age} days old ({csv_date}); tasks created after it are not counted."
                     if age > args.max_age_days else None)

    thr = threshold_for(args.min_month_credits, today)
    pending = credits_check(credits, args.credits_confirmed, thr)
    if pending:  # never net a likely single-task figure without the user's confirmation
        print(json.dumps(pending))
        sys.exit(3)

    try:
        df = pd.read_csv(args.csv, dtype=str, encoding="utf-8-sig", keep_default_na=False)
    except Exception as e:  # unreadable file -> stop, never guess
        fail(f"could not read CSV: {e}")
    df.columns = [c.strip() for c in df.columns]
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        fail(f"CSV is missing column(s): {', '.join(missing)}")

    def local_day(value):
        """Real calendar date of created_date in the user's zone, or None when unparseable."""
        v = str(value).strip()
        if re.match(r"^\d{4}-\d{2}-\d{2}$", v):  # date only: already the user's local date
            try:
                return dt.date.fromisoformat(v)
            except ValueError:  # e.g. 2026-11-99
                return None
        try:
            d = dt.datetime.fromisoformat(v.replace("Z", "+00:00"))  # older CSVs with timestamps
        except ValueError:
            return None
        if d.tzinfo is None:
            d = d.replace(tzinfo=dt.timezone.utc)
        if args.tz:
            from zoneinfo import ZoneInfo
            d = d.astimezone(ZoneInfo(args.tz))
        return d.date()

    # Owner check: every row must belong to the signed-in user.
    users = df["user"].map(lambda v: str(v).strip().lstrip("'").strip())
    empty_report = len(df) == 0  # header-only CSV: a valid report with no tasks -> zero scored tasks
    if (users == "").any():
        rows = [int(i) + 2 for i in df.index[users == ""][:5]]
        fail(f"blank user on CSV line(s) {rows}; every row must name its owner")
    owners = {slugify(u) for u in users}
    if not empty_report and owners != {args.user.lower()}:
        fail(f"CSV rows belong to {sorted(owners)}, not only '{args.user}'")

    # Strict numbers: a scored row (mid_minutes not blank) must have finite, non-negative Low/Mid/High.
    def num(col):
        raw = df[col].str.strip()
        val = pd.to_numeric(raw, errors="coerce")
        return raw, val
    raw_mid, mid = num("mid_minutes")
    raw_low, low = num("low_minutes")
    raw_high, high = num("high_minutes")
    scored = (raw_mid != "").astype(bool)
    def valid(series):
        return series.map(lambda v: v == v and math.isfinite(v) and v >= 0)  # v == v is False for NaN
    bad = scored & ~(valid(mid) & valid(low) & valid(high))
    if bad.any():
        rows = [int(i) + 2 for i in df.index[bad][:5]]
        fail(f"malformed Low/Mid/High minutes on CSV line(s) {rows}; rerun the value report")

    # Band check: a scored row must carry exactly its category's Low/Mid/High minutes.
    cats = df["category"].str.strip()
    def band_ok(i):
        b = BANDS.get(cats[i])
        return b is not None and (low[i], mid[i], high[i]) == tuple(float(x) for x in b)
    off_band = [i for i in df.index[scored] if not band_ok(i)]
    if off_band:
        rows = [int(i) + 2 for i in off_band[:5]]
        fail(f"Low/Mid/High minutes on CSV line(s) {rows} do not match the effort band for their category; "
             "rerun the value report")

    df["_day"] = df["created_date"].map(local_day)
    blank_date = (df["created_date"].str.strip() == "").astype(bool)
    bad_date = scored & df["_day"].isna().astype(bool) & ~blank_date
    if bad_date.any():
        rows = [int(i) + 2 for i in df.index[bad_date][:5]]
        fail(f"invalid created_date on CSV line(s) {rows}; rerun the value report")
    after = scored & df["_day"].map(lambda d: d is not None and d > csv_date).astype(bool)
    if after.any():
        rows = [int(i) + 2 for i in df.index[after][:5]]
        fail(f"created_date after the report snapshot ({csv_date}) on CSV line(s) {rows}; the file is inconsistent")
    df["_month"] = df["_day"].map(lambda d: d.strftime("%Y-%m") if d else None)
    one_off_scored = (~df["recurring_flag"].map(as_bool).astype(bool)) & scored
    undated = int((blank_date & one_off_scored).sum())
    mask = (df["_month"] == month).astype(bool) & one_off_scored

    n = int(mask.sum())
    h = {"low": float(low[mask].sum()) / 60.0, "mid": float(mid[mask].sum()) / 60.0,
         "high": float(high[mask].sum()) / 60.0}
    credit_cost = round(credits * rate, 2)
    row = {"user": args.user, "month": month, "source_csv_date": str(csv_date), "tasks_this_month": n}
    for b in ("low", "mid", "high"):
        row[f"{b}_hours"] = round(h[b], 2)
        row[f"{b}_dollars"] = round(h[b] * RATE_PER_HOUR, 2)   # dollars from unrounded hours
    row.update({"credits_entered": credits, "rate_per_credit": rate, "credit_cost": credit_cost})
    for b in ("low", "mid", "high"):
        row[f"net_{b}"] = round(row[f"{b}_dollars"] - credit_cost, 2)

    os.makedirs(args.out_dir, exist_ok=True)
    out_name = f"cowork_net_value_{args.user}_{month}.csv"
    out_path = os.path.join(args.out_dir, out_name)
    pd.DataFrame([row], columns=OUT_COLUMNS).to_csv(out_path, index=False, encoding="utf-8-sig")
    xlsx_name = out_name[:-4] + ".xlsx"
    xlsx_path = os.path.join(args.out_dir, xlsx_name)
    xlsx_skipped = write_xlsx(xlsx_path, row, not rate_given, identity_check)

    print(json.dumps({"ok": True, **row, "identity_check": identity_check, "empty_report": empty_report,
                      "source_item_parent": sel.get("parent"),
                      "source_csv_name": os.path.basename(args.csv_name),
                      "source_item_id": args.item_id, "source_item_modified": str(mod_date),
                      "rate_defaulted": not rate_given, "credit_threshold": thr,
                      "stale_warning": stale_warning, "csv_age_days": age,
                      "rows_in_csv": int(len(df)), "undated_scored_rows": undated,
                      "out_path": out_path, "out_name": out_name,
                      "xlsx_path": None if xlsx_skipped else xlsx_path,
                      "xlsx_name": None if xlsx_skipped else xlsx_name, "xlsx_skipped": xlsx_skipped,
                      "legend": [{"column": c, "meaning": m} for c, m in LEGEND]}, indent=2))


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("slug")
    s.add_argument("--name", required=True)
    a = sub.add_parser("pick")
    a.add_argument("--user", required=True)
    a.add_argument("--items", required=True,
                   help="JSON list of listed output/ files: name, id, driveId, size, lastModifiedDateTime, "
                        "optional quickXorHash, parentPath")
    a.add_argument("--today", default=None)
    a.add_argument("--max-age-days", type=int, default=MAX_AGE_DAYS)
    a.add_argument("--out", default="working/net_value_pick.json")
    c = sub.add_parser("check-credits")
    c.add_argument("--credits", default=None)
    c.add_argument("--today", default=None)
    c.add_argument("--credits-confirmed", action="store_true")
    c.add_argument("--min-month-credits", type=float, default=MIN_MONTH_CREDITS)
    b = sub.add_parser("compute")
    b.add_argument("--csv", required=True)
    b.add_argument("--selected", default="working/net_value_pick.json",
                   help="selection file written by pick (exact OneDrive item: id, drive, size, modified, hash)")
    b.add_argument("--default-drive-id", required=True, help="GetDefaultDrive id of the signed-in user")
    b.add_argument("--user", required=True)
    b.add_argument("--today", required=True)
    b.add_argument("--tz", default=None)
    b.add_argument("--credits", default=None)
    b.add_argument("--credits-confirmed", action="store_true")
    b.add_argument("--min-month-credits", type=float, default=MIN_MONTH_CREDITS)
    b.add_argument("--rate", default=None)
    b.add_argument("--max-age-days", type=int, default=MAX_AGE_DAYS)
    b.add_argument("--out-dir", default="working")
    args = p.parse_args()
    {"slug": cmd_slug, "pick": cmd_pick, "check-credits": cmd_check_credits,
     "compute": cmd_compute}[args.cmd](args)


if __name__ == "__main__":
    main()
