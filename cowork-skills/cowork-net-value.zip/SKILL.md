---
name: cowork-net-value
description: |
  Nets the signed-in user's Cowork savings ESTIMATE for the current calendar month against the Cowork credit cost of the current billing period: finds the newest cowork_value CSV that cowork-value-report saved under OneDrive Documents/Cowork/Tasks for this user, refuses one from an earlier month, sums this month's scored one-off tasks at $72/hr in the Low, Mid and High bands, asks once for the credit count and $-per-credit rate, and returns a NET verdict per band plus a one-row CSV plus an Excel workbook (Results and Legend tabs). Validated in commercial Microsoft 365; for GCC, confirm Cowork availability and billing with the tenant admin first. Do not assume the commercial $0.01 rate in GCC. Use when the user says "net my Cowork value", "Cowork net savings", "Cowork value minus credits" or "what did Cowork actually cost me net of savings". Do NOT use to run the base value report (use cowork-value-report / "run my Cowork value" instead), for past billing periods, or for other users' data.
metadata:
  category: analysis
  icon: Money
---

# Cowork Net Value (personal ESTIMATE, current billing period only)

Companion to **cowork-value-report**. Takes the itemized CSV that skill already produced, keeps only this month's scored one-off tasks, and nets their savings ESTIMATE (Low, Mid and High bands) against what this billing period's Cowork credits cost.
Every figure is an **ESTIMATE** or **APPROXIMATE** — never billed, measured or actual savings.

## When to Use

- "Net my Cowork value" / "Cowork net savings" / "Cowork value minus credits"
- "What did Cowork actually cost me net of savings?"
- The user has run cowork-value-report this month (its CSV is the input)

## When NOT to Use

- Running the base value report or refreshing the task CSV — use **cowork-value-report** ("run my Cowork value") instead
- Any billing period other than the current one — credit data exists only for the current period, never historical
- Another person's tasks or credits, or a team roll-up that compares people — decline
- Invoices, licensing or billed cost questions — this skill only estimates

## Workflow

### Step 1 — Find the input CSV and check it is current (no prompts)
1. Get the user's display name with `GetMyDetails` and slug it with code: `python scripts/net_value.py slug --name "<display name>"` (same rule as cowork-value-report; never slug by hand). Get the user's local date and IANA zone with `GetUserDateAndTimeZoneSettings` (load via `tool_search_tool`; if it fails, use the session date, omit `--tz` and say so in one line).
2. List the task folders: `ExecuteSql` `SELECT name, id FROM drive_children WHERE folder_path = '/Documents/Cowork/Tasks'` (add `TOP N` if it says there are more rows than the default fetch; fallback `GetDriveChildren`, load via `tool_search_tool`).
3. For every task folder, list its `output/` child folder's files in batches — `drive_children WHERE item_id IN (...)` (≤50 ids per statement), or a `core-RunScript` loop — selecting at least **name, id, size, lastModifiedDateTime** and the drive id the rows come from — plus the file's **quickXorHash** (`file.hashes.quickXorHash`) when the listing tool exposes it. Never one manual call per folder. No `output/` = no candidates. Also call `GetDefaultDrive` once and keep its drive id (the signed-in user's own OneDrive).
4. Write every listed `output/` file to `working/net_value_items.json`, exactly as returned — one object per file: `{"name", "id", "driveId", "size", "lastModifiedDateTime", "quickXorHash" (only if exposed), "parentPath"}`. Then pick **one exact item** with code:
   `python scripts/net_value.py pick --user <slug> --today <yyyy-mm-dd> --items working/net_value_items.json --out working/net_value_pick.json`
   It matches `cowork_value_<slug>_<yyyy-mm-dd>[-<HHMM>].csv` for this user only (other users' files are ignored and counted) and orders candidates by the date in the name, then **latest `lastModifiedDateTime`** — every report run publishes into its own task folder, so same-named CSVs are normal — then `-HHMM`, then item id. It returns the selected item's **id** and writes it, with drive id, size, modified time and hash, to `working/net_value_pick.json`; it also lists `same_name_older_copies` and items skipped for missing metadata, and reports `current_month`, `age_days` and `stale_warning`. Never choose a file yourself.
5. **`found: false`:** say "I couldn't find a cowork_value CSV for you yet — run **run my Cowork value** first, then ask me again." and stop.
   **`current_month: false`:** say "Your newest Cowork value CSV is from {date}, before this billing month, so netting it against this month's credits would be wrong — run **run my Cowork value** first, then ask me again." and stop. Do not ask for credits.
   **`stale_warning` set:** continue, and put the warning in the Verdict block (below). Optionally suggest rerunning the value report for a complete month-to-date figure.
6. Download **the selected item id** read-only: `ReadFileContent(drive_id=<selection driveId>, item_id=<selection id>, mode="download")` gives a local `cloud/...` copy. `compute` reads the rest from `working/net_value_pick.json` — never retype ids, sizes or hashes. Never write, move or rename anything in `Documents/Cowork/Tasks`, and never ask the user to upload or re-upload this CSV.

### Step 2 — Ask once for credits (the one manual input)
No tool available to a skill can read Cowork credits, so ask **once, in a single message**, for both:
- (a) "Open any Cowork task (a new blank one is fine) and type **/cost**. On the card that appears, use the number next to **'credits used so far this month'** -- NOT the smaller 'credits used for this task' number right above it. Tell me that larger month-to-date number." Only if /cost isn't available, add: "If /cost isn't available, try **Settings > Usage** -- but its first screen may only show a chart or a percentage remaining with no usable total."
- (b) "What's your $-per-credit rate? (default $0.01 if you don't know -- that's the public Copilot Credit pay-as-you-go list price; prepaid plans or negotiated agreements can make your organisation's effective rate lower)."

Accept a plain number for each. Use the $0.01 default only when the user gives no rate. If no credit count is given, say "I can't net the value without this period's credit count, so I've stopped here." and stop — never estimate credits.

**Sanity-check the credit count with code (mandatory):** `python scripts/net_value.py check-credits --credits <n> --today <yyyy-mm-dd>`. The threshold is 1,000 credits for a full month, prorated by day of month (minimum 100), so early-month totals are not flagged. Exit 3 with `needs_confirmation`: ask the script's `ask` text once, plainly. If the user re-confirms the same number, re-run with `--credits-confirmed` and proceed; if they give a new number, check that one (a re-confirmed value always passes). Ask at most once — never loop. `compute` runs the same check.

**Screenshot instead of a number:** read it only if it shows clear, legible text that explicitly gives the month-to-date total, such as "N credits used so far this month". Extract N, tell the user what you read ("I read N credits used so far this month — is that right?") and proceed once confirmed (N then goes through the same sanity check). If the image only shows a percentage remaining and/or an unlabeled bar chart, do NOT guess from bar heights: say the image doesn't show a usable total and repeat the /cost instruction from (a).

### Step 3 — Compute with code (never mentally)
```bash
python scripts/net_value.py compute --csv <cloud path> --selected working/net_value_pick.json \
  --default-drive-id <GetDefaultDrive id> --user <slug> --today <yyyy-mm-dd> [--tz <IANA zone>] --credits <n> [--credits-confirmed] [--rate <r>] --out-dir working
```
It verifies the file before any math — the downloaded file's size matches the selected item (a **size check**: it catches a different-size file, not a different file of the same size); when the listing supplied a quickXorHash it also recomputes the hash over the downloaded bytes, which is a **content check**; the output field `identity_check` says which one ran — the name belongs to this user's slug, the drive is the user's own OneDrive, every row's `user` is present and is the signed-in user, the item's modified time is not before the date in its name, every scored row carries exactly its category's Low/Mid/High band minutes and a real calendar created date (or blank) no later than the report snapshot, and credits/rate are finite numbers — and exits 2 naming the problem otherwise; never work around a failed check. It refuses a CSV from an earlier month (exit 4), filters to rows whose `created_date` is in the current calendar month (local), `recurring_flag` not set and `mid_minutes` populated; sums Low/Mid/High minutes → hours (/60) → dollars at **$72/hr**; computes `credit_cost = credits × rate` and `net_<band> = <band>_dollars − credit_cost`; and writes `working/cowork_net_value_<slug>_<yyyy-mm>.csv` with the columns
`user, month, source_csv_date, tasks_this_month, low_hours, low_dollars, mid_hours, mid_dollars, high_hours, high_dollars, credits_entered, rate_per_credit, credit_cost, net_low, net_mid, net_high`.

Exit codes: 3 = credits failed the sanity check and were not confirmed (ask once as in Step 2, then re-run); 4 = CSV from an earlier month (same message as Step 1.5, stop); 2 = bad input or a failed file check (size mismatch, wrong or blank owner, wrong drive, inconsistent timestamp, off-band minutes, invalid or post-snapshot dates, non-numeric or non-finite entry) — report the message in one line, suggest rerunning "run my Cowork value" when the CSV itself is at fault, and stop. Quote every figure from the script's JSON output only. Zero tasks this month is a valid result, including a header-only report CSV with no tasks at all (`empty_report: true`): report it (each net is then minus the credit cost) rather than stopping.

### Step 4 — Publish the CSV and the workbook
`compute` writes two files from the same row and the same column definitions:
- `working/cowork_net_value_<slug>_<yyyy-mm>.csv` — **one row, for automated use** (header = the exported columns, unchanged order);
- `working/cowork_net_value_<slug>_<yyyy-mm>.xlsx` — **Results** tab (the same columns and values, with the ESTIMATE note and File check line) and **Legend** tab (one row per exported column).
Publish both: `CopyArtifact(surface="output", source="working/<out_name>", destination="<out_name>")`, then the same for `<xlsx_name>`. On `source not visible yet`, wait a few seconds and re-issue the same call once. If refused because the name already exists (a rerun this month), publish **both** with the same `-<yyyy-mm-dd>-<HHMM>` suffix and name them. Confirm `ok: true` and the result path for each before saying it is saved; if one fails, say which. If `xlsx_skipped` is set (openpyxl missing), publish the CSV only and say "Excel workbook skipped: <reason>".

## Output Format

```
**Verdict — NET value ESTIMATE, {month}:** NET (Savings minus credit cost) ~${net_mid} Mid / ~${net_low} Low / ~${net_high} High.
{stale_warning, if set}
File check: {identity_check}
{If undated_scored_rows > 0: "{undated_scored_rows} scored task(s) had no created date and are not counted."}

- This month's scored one-off tasks: {tasks_this_month} (from `{source_csv_name}`, item `{source_item_id}` in `{source_item_parent}`, modified {source_item_modified}){ — if pick reported same_name_older_copies: " newest of {n+1} reports with this name"}
- Savings ESTIMATE at $72/hr: Low {low_hours} h (~${low_dollars}); Mid {mid_hours} h (~${mid_dollars}); High {high_hours} h (~${high_dollars})
- Credit cost (APPROXIMATE): {credits_entered} credits × ${rate_per_credit} = ${credit_cost}{ — default rate, if used}
- **NET (Savings minus credit cost) ESTIMATE:** Low ${net_low}; Mid ${net_mid}; High ${net_high}
- The net leans conservative: credits cover all of this month's Cowork use (including recurring automation and tasks started last month), but only this month's scored one-off tasks count as savings.

What each column means (CSV and workbook):
| Column | Meaning |
|---|---|
| {legend[i].column} | {legend[i].meaning} |   ← one row per entry of `legend`, in order, verbatim

Caveats:
- This nets only this billing period's scored tasks against this billing period's credits -- it does NOT net against your full task-history total, since credit history isn't available beyond the current period.
- The $-per-credit rate is user-supplied or the public pay-as-you-go list price, not a confirmed tenant-negotiated rate.

CSV (one row, for automation): output/<out_name>
Excel workbook (Results + Legend): output/<xlsx_name>
```
**The column legend is mandatory on every run:** show it right after the Verdict numbers as the table above, with **one row per entry of `compute`'s `legend` field, in order and verbatim** — that field, the CSV header and the workbook's Results and Legend tabs are all generated from the same `COLUMN_DEFS` in `scripts/net_value.py`, so every exported column is covered. Never type the legend from memory, merge rows, drop it, shorten it to prose or skip it because the user has seen it before. Lead with Mid; Low is the defensible floor; High is for completeness.
A negative net is written plainly with a minus sign (e.g. "NET −$12.40") — never hidden, rounded away or softened. Keep prose to a few lines.

## Guardrails

- **ESTIMATE labelling:** every figure says ESTIMATE or APPROXIMATE; never call it billed, measured, actual or realized savings.
- **Own activity only:** `pick --user` and `compute`'s owner/drive checks use only the signed-in user's CSV on their own OneDrive; refuse other users' data and any comparison of people.
- **No fabrication:** if the CSV or the credit count is missing, say so and stop — never guess, pad or reuse a past figure.
- **Current period only:** never net a CSV from an earlier month, the full task history or a past billing period.
- **Code for math:** every count, hour and dollar figure comes from `scripts/net_value.py` output.
- **Read-only on Tasks:** never write, move, rename or delete anything in `Documents/Cowork/Tasks`; never ask the user to re-upload any CSV.
- **One question only:** the credits/rate message is the single prompt in the run — except the one-time credits confirmation from the sanity check, and repeating the /cost instruction when a screenshot shows no usable month-to-date total.
- **No guessing from images:** never estimate credits from bar heights or a percentage remaining.
- **Cloud scope:** validated in commercial Microsoft 365. If the user says their tenant is GCC, note the skill has not yet been validated there and that the $0.01 default is the commercial list price; proceed only once they confirm Cowork is enabled for them, and ask them to supply their own rate rather than using the default.

## Common Issues

| Issue | Fix |
|---|---|
| No `cowork_value_<slug>_…csv` in any `output/` folder | Tell the user to run "run my Cowork value" first; stop |
| Newest CSV is from an earlier month (`current_month: false` / exit 4) | Tell the user to run "run my Cowork value" first; stop before asking for credits |
| CSV is a few days old (`stale_warning`) | Proceed; show the warning in the Verdict; suggest rerunning the value report |
| Several CSVs for this user | `pick` takes the newest date in the name, then the latest modified item, then `-HHMM`; it returns one exact item id |
| Same file name in several task folders | Normal (each report run has its own `output/`); `pick` selects the latest modified one and lists the others in `same_name_older_copies` |
| `pick` lists items in `skipped_incomplete` | The listing lacked id/driveId/size/lastModifiedDateTime for them; re-list with those columns |
| Download doesn't match the selection (size or hash) | `compute` exits 2: the wrong copy was downloaded — download the selection's exact item id and rerun `compute` |
| Other users' CSVs present | `pick --user` ignores them (`ignored_other_users`); never use them |
| CSV lacks a required column (e.g. `high_minutes`) | Script exits 2 naming it; ask the user to rerun "run my Cowork value"; stop |
| `compute` exits 2 on size, owner, drive, timestamp, band or date checks | Report the message; do not pick another file or pass different values to get past it; suggest rerunning the value report; stop |
| Listing exposes no quickXorHash | Omit it from the items file; the Verdict's "File check" line says "size only" — never describe that as content verification |
| QuickXorHash mismatch | The download is not the selected item; report it and stop |
| User enters "NaN", "inf" or similar | Rejected as not a finite number; report it and stop |
| User gives the small /cost "credits used for this task" number | `check-credits` flags values under the prorated threshold: ask once; accept a re-confirmed value with `--credits-confirmed` |
| Settings > Usage shows only a percentage or a bar chart | Not a usable total — repeat the /cost instruction |
| User gives "$0.008" or "1,250" | The script strips `$` and `,`; anything else non-numeric: report it and stop (do not ask again) |
| No rate given | Use $0.01 and say the default was used |
| Net is negative | Report the negative figure plainly |
| `xlsx_skipped` set | openpyxl is unavailable: publish the CSV only; say "Excel workbook skipped: <reason>"; the chat legend is still shown |
| A column is added to the output | Add it to `COLUMN_DEFS` in `scripts/net_value.py` only — the CSV, both workbook tabs and the chat legend follow automatically |
| Output CSV publish returns `source not visible yet` | Wait a few seconds and re-issue the same call once |
| Output CSV name already exists this month | Publish with the `-<yyyy-mm-dd>-<HHMM>` suffix |
